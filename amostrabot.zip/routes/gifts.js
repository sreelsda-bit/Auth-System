const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Caminhos dos arquivos
const giftsPath = path.join(__dirname, '..', 'database', 'gifts.json');
const usersPath = path.join(__dirname, '..', 'database', 'users.json');
const dbPathAuth = path.join(__dirname, '..', 'database', 'configauth02api.json');
const configPath = path.join(__dirname, '..', 'config.json');

// Função para gerar código único do gift
function gerarCodigoGift() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const partes = [];
    for (let i = 0; i < 4; i++) {
        let parte = '';
        for (let j = 0; j < 4; j++) {
            parte += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        partes.push(parte);
    }
    return partes.join('-');
}

// Função para carregar gifts
function carregarGifts() {
    if (!fs.existsSync(giftsPath)) {
        fs.writeFileSync(giftsPath, '[]');
        return [];
    }
    try {
        return JSON.parse(fs.readFileSync(giftsPath, 'utf-8'));
    } catch (e) {
        return [];
    }
}

// Função para salvar gifts
function salvarGifts(gifts) {
    fs.writeFileSync(giftsPath, JSON.stringify(gifts, null, 4));
}

// Função para enviar log via webhook
async function enviarLogWebhook(embed, webhookUrl) {
    try {
        if (!webhookUrl || webhookUrl === 'COLOQUE_SEU_WEBHOOK_AQUI') {
            return;
        }
        await axios.post(webhookUrl, { embeds: [embed] });
    } catch (error) {
        console.error('❌ Erro ao enviar log para webhook:', error.message);
    }
}

// 1. Criar Gift
router.post('/criar', async (req, res) => {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`📨 REQUISIÇÃO RECEBIDA: Criar Gift`);
    console.log(`${'='.repeat(60)}`);
    console.log(`⏰ Timestamp: ${new Date().toLocaleString('pt-BR')}`);
    console.log(`🔑 Authorization: ${req.headers.authorization ? '✅ Presente' : '❌ Ausente'}`);
    console.log(`📦 Body:`, JSON.stringify(req.body, null, 2));

    // Validação de autenticação
    const authHeader = req.headers.authorization;
    if (authHeader !== 'galaodamassa581') {
        console.error('❌ ERRO: Não autorizado');
        console.log(`${'='.repeat(60)}\n`);
        return res.status(403).json({ sucesso: false, erro: 'Não autorizado' });
    }

    console.log('✅ Validação inicial passou');

    const { bot_id, quantidade, criado_por } = req.body;

    // Validação de parâmetros
    if (!bot_id || !quantidade) {
        console.error('❌ ERRO: Parâmetros ausentes');
        console.log(`${'='.repeat(60)}\n`);
        return res.status(400).json({ sucesso: false, erro: 'bot_id e quantidade são obrigatórios' });
    }

    try {
        // Carrega configuração do bot
        console.log('🔍 Validando bot...');
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[bot_id];

        if (!configBot) {
            console.error(`❌ ERRO: Bot ${bot_id} não encontrado`);
            console.log(`${'='.repeat(60)}\n`);
            return res.status(404).json({ sucesso: false, erro: 'Bot não encontrado' });
        }

        console.log(`✅ Bot encontrado: ${configBot.bot_name || bot_id}`);

        // Verifica membros disponíveis
        console.log('📊 Verificando membros disponíveis...');
        let allUsers = {};
        if (fs.existsSync(usersPath)) {
            allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
        }

        const botUsers = allUsers[bot_id] || {};
        const membrosDisponiveis = Object.keys(botUsers).length;

        if (membrosDisponiveis < quantidade) {
            console.error(`❌ ERRO: Membros insuficientes (disponível: ${membrosDisponiveis}, solicitado: ${quantidade})`);
            console.log(`${'='.repeat(60)}\n`);
            return res.status(400).json({
                sucesso: false,
                erro: `Membros insuficientes. Disponível: ${membrosDisponiveis}, solicitado: ${quantidade}`
            });
        }

        console.log(`✅ Membros disponíveis: ${membrosDisponiveis}`);

        // Gera código único
        console.log('🎁 Gerando gift...');
        let codigo;
        let gifts = carregarGifts();
        do {
            codigo = gerarCodigoGift();
        } while (gifts.some(g => g.codigo === codigo));

        // Carrega config para pegar URL base
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        const baseUrl = config.url_base || 'https://ilusionsoluctions.camposcloud.app';

        // Cria gift
        const gift = {
            codigo: codigo,
            bot_id: bot_id,
            bot_name: configBot.bot_name || 'Bot',
            quantidade: quantidade,
            criado_por: criado_por || 'Sistema',
            criado_em: new Date().toISOString(),
            resgatado: false,
            resgatado_por: null,
            resgatado_em: null,
            guild_id: null,
            pedido_id: null,
            status: 'ativo',
            link: `${baseUrl}/gift/${codigo}`
        };

        gifts.push(gift);
        salvarGifts(gifts);

        console.log('✅ Gift salvo no banco de dados');

        // Envia log via webhook
        const corEmbed = config.cor_embed || 8134125;
        const embed = {
            title: '🎁 Novo Gift Criado',
            description: `Um novo gift de membros foi criado no sistema **${config.nome_sistema || 'Ilusion Auth02 API'}**.`,
            color: corEmbed,
            fields: [
                { name: '🎫 Código', value: `\`${gift.codigo}\``, inline: false },
                { name: '🤖 Bot', value: `**${gift.bot_name}**`, inline: true },
                { name: '📊 Quantidade', value: `\`${gift.quantidade}\` membros`, inline: true },
                { name: '👤 Criado por', value: gift.criado_por, inline: true },
                { name: '🔗 Link de Resgate', value: `[Clique aqui](${gift.link})`, inline: false },
                { name: '⏰ Criado em', value: `<t:${Math.floor(new Date(gift.criado_em).getTime() / 1000)}:F>`, inline: false }
            ],
            thumbnail: { url: config.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png' },
            footer: { text: config.nome_sistema || 'Ilusion Auth02 API' },
            timestamp: new Date().toISOString()
        };

        await enviarLogWebhook(embed, config.webhook_logs);

        console.log('✅ SUCESSO: Gift criado com sucesso!');
        console.log(`${'='.repeat(60)}\n`);

        res.json({
            sucesso: true,
            mensagem: 'Gift criado com sucesso!',
            gift: {
                codigo: gift.codigo,
                link: gift.link,
                link_resgate: gift.link,
                quantidade: gift.quantidade,
                bot_name: gift.bot_name,
                bot_id: gift.bot_id,
                criado_em: gift.criado_em,
                status: gift.status
            }
        });

    } catch (error) {
        console.error('❌ ERRO CRÍTICO:', error);
        console.log(`${'='.repeat(60)}\n`);
        res.status(500).json({ sucesso: false, erro: error.message });
    }
});

// 2. Consultar Gift
router.get('/:codigo', (req, res) => {
    const { codigo } = req.params;

    try {
        const gifts = carregarGifts();
        const gift = gifts.find(g => g.codigo === codigo);

        if (!gift) {
            return res.status(404).json({ sucesso: false, erro: 'Gift não encontrado' });
        }

        // Carrega config do bot
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[gift.bot_id];

        res.json({
            sucesso: true,
            gift: {
                codigo: gift.codigo,
                bot_id: gift.bot_id,
                bot_name: gift.bot_name,
                quantidade: gift.quantidade,
                status: gift.status,
                resgatado: gift.resgatado,
                resgatado_em: gift.resgatado_em,
                criado_em: gift.criado_em,
                pedido_id: gift.pedido_id,
                bot_invite: `https://discord.com/api/oauth2/authorize?client_id=${gift.bot_id}&permissions=1&scope=bot`
            }
        });

    } catch (error) {
        res.status(500).json({ sucesso: false, erro: error.message });
    }
});

// 3. Resgatar Gift
router.post('/:codigo/resgatar', async (req, res) => {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`🎉 REQUISIÇÃO: Resgatar Gift`);
    console.log(`${'='.repeat(60)}`);
    console.log(`   Código: ${req.params.codigo}`);
    console.log(`   Guild ID: ${req.body.guild_id}`);

    const { codigo } = req.params;
    const { guild_id } = req.body;

    if (!guild_id) {
        console.error('❌ ERRO: guild_id ausente');
        console.log(`${'='.repeat(60)}\n`);
        return res.status(400).json({ sucesso: false, erro: 'guild_id é obrigatório' });
    }

    try {
        console.log('🔍 Buscando gift...');
        const gifts = carregarGifts();
        const giftIndex = gifts.findIndex(g => g.codigo === codigo);

        if (giftIndex === -1) {
            console.error('❌ ERRO: Gift não encontrado');
            console.log(`${'='.repeat(60)}\n`);
            return res.status(404).json({ sucesso: false, erro: 'Gift não encontrado' });
        }

        const gift = gifts[giftIndex];
        console.log(`✅ Gift encontrado: ${gift.bot_name} - ${gift.quantidade} membros`);

        if (gift.resgatado) {
            console.error('❌ ERRO: Gift já foi resgatado');
            console.log(`${'='.repeat(60)}\n`);
            return res.status(400).json({ sucesso: false, erro: 'Gift já foi resgatado' });
        }

        if (gift.status !== 'ativo') {
            console.error(`❌ ERRO: Gift não está disponível (status: ${gift.status})`);
            console.log(`${'='.repeat(60)}\n`);
            return res.status(400).json({ sucesso: false, erro: 'Gift não está disponível' });
        }

        // Valida bot
        console.log('🤖 Validando bot...');
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[gift.bot_id];

        if (!configBot || !configBot.token) {
            console.error('❌ ERRO: Bot não configurado');
            console.log(`${'='.repeat(60)}\n`);
            return res.status(400).json({ sucesso: false, erro: 'Bot não configurado' });
        }

        console.log(`✅ Bot configurado: ${configBot.bot_name || gift.bot_id}`);

        // Verifica se bot está no servidor
        console.log('🏠 Verificando se bot está no servidor...');
        try {
            const guildResponse = await axios.get(
                `https://discord.com/api/v10/guilds/${guild_id}`,
                { headers: { Authorization: `Bot ${configBot.token.trim()}` } }
            );
            console.log(`✅ Bot confirmado no servidor: ${guildResponse.data.name}`);
        } catch (error) {
            console.error('❌ ERRO: Bot não está no servidor');
            console.log(`${'='.repeat(60)}\n`);
            return res.status(403).json({
                sucesso: false,
                erro: 'Bot não está no servidor. Adicione o bot primeiro.',
                bot_invite: `https://discord.com/api/oauth2/authorize?client_id=${gift.bot_id}&permissions=1&scope=bot`
            });
        }

        // Adiciona pedido na fila (importa função do server.js)
        const { adicionarNaFila } = require('../server.js');
        const pedidoId = adicionarNaFila({
            bot_id: gift.bot_id,
            guild_id: guild_id,
            quantidade: gift.quantidade
        });

        // Atualiza gift
        console.log('🎁 Resgatando gift...');
        gifts[giftIndex].resgatado = true;
        gifts[giftIndex].resgatado_em = new Date().toISOString();
        gifts[giftIndex].guild_id = guild_id;
        gifts[giftIndex].pedido_id = pedidoId;
        gifts[giftIndex].status = 'processando';
        salvarGifts(gifts);

        console.log('✅ Gift resgatado e salvo');

        // Envia logs via webhook
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        const corEmbed = config.cor_embed || 8134125;

        // Webhook global
        const embedGlobal = {
            title: '🎉 Gift Resgatado',
            description: `Um gift foi resgatado e o pull de membros foi iniciado.`,
            color: corEmbed,
            fields: [
                { name: '🎫 Código', value: `\`${gift.codigo}\``, inline: false },
                { name: '🤖 Bot', value: `**${gift.bot_name}**`, inline: true },
                { name: '📊 Quantidade', value: `\`${gift.quantidade}\` membros`, inline: true },
                { name: '🏠 Servidor', value: `\`${guild_id}\``, inline: true },
                { name: '📋 Pedido ID', value: `\`${pedidoId}\``, inline: false },
                { name: '⏰ Resgatado em', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
            ],
            thumbnail: { url: config.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png' },
            footer: { text: config.nome_sistema || 'Ilusion Auth02 API' },
            timestamp: new Date().toISOString()
        };

        await enviarLogWebhook(embedGlobal, config.webhook_logs);

        // Webhook do bot
        if (configBot.webhook_logs) {
            const embedBot = {
                title: '🎉 Gift Resgatado no Seu Bot',
                description: `Um gift do bot **${gift.bot_name}** foi resgatado.`,
                color: corEmbed,
                fields: [
                    { name: '🎫 Código do Gift', value: `\`${gift.codigo}\``, inline: false },
                    { name: '📊 Quantidade de Membros', value: `\`${gift.quantidade}\` membros`, inline: true },
                    { name: '🏠 Servidor de Destino', value: `\`${guild_id}\``, inline: true },
                    { name: '📋 ID do Pedido', value: `\`${pedidoId}\``, inline: false },
                    { name: '⏰ Resgatado em', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
                    { name: 'ℹ️ Informação', value: 'Os membros estão sendo puxados para o servidor...', inline: false }
                ],
                footer: { text: gift.bot_name },
                timestamp: new Date().toISOString()
            };

            await enviarLogWebhook(embedBot, configBot.webhook_logs);
        }

        console.log('✅ SUCESSO: Gift resgatado e pull iniciado!');
        console.log(`${'='.repeat(60)}\n`);

        res.json({
            sucesso: true,
            mensagem: 'Gift resgatado com sucesso! Pull iniciado.',
            pedido_id: pedidoId,
            quantidade: gift.quantidade,
            endpoint_status: `/api/auth02/pedido/${pedidoId}`
        });

    } catch (error) {
        console.error('❌ ERRO CRÍTICO:', error);
        console.log(`${'='.repeat(60)}\n`);
        res.status(500).json({ sucesso: false, erro: error.message });
    }
});

// 4. Status do Gift
router.get('/:codigo/status', (req, res) => {
    const { codigo } = req.params;

    try {
        const gifts = carregarGifts();
        const gift = gifts.find(g => g.codigo === codigo);

        if (!gift) {
            return res.status(404).json({ sucesso: false, erro: 'Gift não encontrado' });
        }

        const response = {
            sucesso: true,
            gift: {
                codigo: gift.codigo,
                quantidade: gift.quantidade,
                status: gift.status,
                resgatado: gift.resgatado,
                resgatado_em: gift.resgatado_em,
                guild_id: gift.guild_id
            }
        };

        // Se foi resgatado, busca status do pedido
        if (gift.pedido_id) {
            const { filaPulls } = require('../server.js');
            const pedido = filaPulls.pedidos.get(gift.pedido_id);

            if (pedido) {
                response.pull = {
                    status: pedido.status,
                    progresso: {
                        atual: pedido.progresso,
                        total: pedido.total,
                        porcentagem: Math.round((pedido.progresso / pedido.total) * 100)
                    },
                    resultados: {
                        sucessos: pedido.sucessos,
                        falhas: pedido.falhas
                    }
                };

                // Atualiza status do gift se pull concluído
                if (pedido.status === 'concluido' && gift.status !== 'concluido') {
                    const giftIndex = gifts.findIndex(g => g.codigo === codigo);
                    gifts[giftIndex].status = 'concluido';
                    salvarGifts(gifts);
                    response.gift.status = 'concluido';
                }
            }
        }

        res.json(response);

    } catch (error) {
        res.status(500).json({ sucesso: false, erro: error.message });
    }
});

// 5. Listar Gifts (Admin)
router.get('/listar', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== 'galaodamassa581') {
        return res.status(403).json({ sucesso: false, erro: 'Não autorizado' });
    }

    try {
        const gifts = carregarGifts();

        const estatisticas = {
            total: gifts.length,
            ativos: gifts.filter(g => g.status === 'ativo').length,
            resgatados: gifts.filter(g => g.resgatado).length,
            processando: gifts.filter(g => g.status === 'processando').length,
            concluidos: gifts.filter(g => g.status === 'concluido').length
        };

        res.json({
            sucesso: true,
            estatisticas: estatisticas,
            gifts: gifts.map(g => ({
                codigo: g.codigo,
                bot_name: g.bot_name,
                quantidade: g.quantidade,
                status: g.status,
                resgatado: g.resgatado,
                criado_em: g.criado_em,
                link: g.link
            }))
        });

    } catch (error) {
        res.status(500).json({ sucesso: false, erro: error.message });
    }
});

module.exports = router;
