router.get('/api/oauth02', async (req, res) => {
    const { code } = req.query;

    if (!code) return res.status(400).send("Código ausente.");

    try {
        // 1. Carrega configs do bot
        const authData = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));

        // 2. Troca o code pelo token
        const params = new URLSearchParams({
            client_id: authData.bot_id,
            client_secret: authData.secret,
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: `https://gamacloud.camposcloud.app/api/oauth02`,
            scope: 'identify guilds.join'
        });

        const tokenResponse = await axios.post('https://discord.com/api/v10/oauth2/token', params, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        const { access_token, refresh_token } = tokenResponse.data;

        // 3. Busca dados do usuário para exibir na página de sucesso
        const userResponse = await axios.get('https://discord.com/api/v10/users/@me', {
            headers: { 'Authorization': `Bearer ${access_token}` }
        });

        const userData = userResponse.data;

        // 4. Salva no banco de dados (users.json)
        // [Aqui vai o seu código de salvamento por allUsers[botID]...]

        // 5. Gera código aleatório para a URL
        const crypto = require('crypto');
        const authCode = crypto.randomBytes(16).toString('hex');

        // 6. Prepara os dados para a página de sucesso
        const avatarURL = userData.avatar 
            ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` 
            : `https://cdn.discordapp.com/embed/avatars/${userData.discriminator % 5}.png`;

        const queryData = encodeURIComponent(JSON.stringify({
            username: userData.username,
            avatar: avatarURL
        }));

        // Redireciona para o seu arquivo HTML com nome cabuloso
        res.redirect(`/authentication=${authCode}?data=${queryData}`);

    } catch (error) {
        console.error(error);
        res.status(500).send("Erro na verificação.");
    }
});