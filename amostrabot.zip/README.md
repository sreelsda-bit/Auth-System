# 🚀 Ilusion Auth02 API

API completa de gerenciamento de autenticação OAuth2 do Discord com sistema de pull de membros, fila de processamento, rotação automática de arquivos e logs via webhook.

## 📋 Índice

- [Características](#características)
- [Instalação](#instalação)
- [Configuração](#configuração)
- [Documentação](#documentação)
- [Endpoints Principais](#endpoints-principais)
- [Webhooks](#webhooks)
- [Suporte](#suporte)

---

## ✨ Características

### 🔐 Autenticação OAuth2
- Sistema completo de OAuth2 do Discord
- Refresh automático de tokens (até 3 tentativas)
- Atribuição automática de cargos
- Geolocalização e detecção de dispositivo
- Página de sucesso personalizada por servidor

### 👥 Pull de Membros
- Sistema de fila assíncrona
- Delay inteligente entre pulls (1.5s)
- Detecção de limite de 100 servidores
- Identificação de usuários banidos
- Logs detalhados no console

### 🗑️ Limpeza Automática
- Exclusão de usuários com tokens inválidos
- 3 tentativas de renovação antes de excluir
- Mantém o banco de dados limpo

### 📦 Rotação de Arquivos
- Rotação automática ao atingir 5MB
- Backups com timestamp
- Gerenciamento de backups via API

### 🎁 Sistema de Gifts
- Criação de códigos únicos de resgate
- Links personalizados para cada gift
- Página web para resgate
- Progresso em tempo real
- Validação de bot no servidor
- Notificações de novos bots configurados
- Alertas de pulls iniciados e finalizados
- Logs de usuários excluídos
- Embeds personalizáveis

---

## 🛠️ Instalação

### Requisitos
- Node.js 16+
- npm ou yarn

### Passo 1: Instalar Dependências

```bash
npm install
```

### Passo 2: Configurar Webhooks (Opcional)

Copie o arquivo de exemplo:
```bash
copy config.example.json config.json
```

Edite `config.json` e adicione seu webhook do Discord.

### Passo 3: Iniciar o Servidor

```bash
npm start
```

O servidor estará rodando em `http://localhost:3000` (ou porta configurada).

---

## ⚙️ Configuração

### 1. Configurar Webhook Global (config.json)

```json
{
  "webhook_logs": "https://discord.com/api/webhooks/SEU_WEBHOOK",
  "nome_sistema": "Ilusion Auth02 API",
  "cor_embed": 8134125,
  "icone_sistema": "https://i.imgur.com/logo.png"
}
```

📖 [Guia Completo de Configuração de Webhooks](CONFIGURACAO_WEBHOOK.md)

### 2. Configurar um Bot

Faça uma requisição POST para `/api/auth02/configurar`:

```bash
curl -X POST https://seu-dominio.com/api/auth02/configurar \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "SEU_USER_ID",
    "client_secret": "SEU_CLIENT_SECRET",
    "token": "SEU_BOT_TOKEN"
  }'
```

Você receberá o link de autenticação pronto para uso!

---

## 📚 Documentação

### Documentação Completa da API
📖 [API_DOCUMENTATION.md](API_DOCUMENTATION.md)

Inclui:
- Todos os endpoints
- Parâmetros e respostas
- Exemplos de uso
- Códigos de erro
- Logs do console

### Sistema de Gifts
📖 [SISTEMA_GIFTS.md](SISTEMA_GIFTS.md)

Inclui:
- Como criar gifts
- Como resgatar gifts
- Integração com bots
- Exemplos práticos
- Página de resgate

### Guia de Webhooks
📖 [CONFIGURACAO_WEBHOOK.md](CONFIGURACAO_WEBHOOK.md)

Inclui:
- Como criar webhooks no Discord
- Configuração passo a passo
- Exemplos de embeds
- Troubleshooting

### Página de Verificação
📖 [PAGINA_VERIFICACAO.md](PAGINA_VERIFICACAO.md)

Inclui:
- Como funciona a personalização
- Exemplos visuais
- Customização de cores e tempo
- Tratamento de erros

### Changelog
📖 [CHANGELOG.md](CHANGELOG.md)

Histórico de versões e atualizações.

---

## 🔌 Endpoints Principais

### Autenticação

```
GET  /auth02/verify
POST /api/auth02/configurar
GET  /api/auth02/info/:botID
```

### Pull de Membros

```
POST /api/auth02/pull
GET  /api/auth02/pedido/:pedidoId
GET  /api/auth02/pedido/:pedidoId/logs
GET  /api/auth02/fila
```

### Backups

```
GET  /api/auth02/backups
POST /api/auth02/rotacionar
GET  /api/auth02/status-arquivo
```

---

## 📨 Webhooks

A API envia notificações automáticas via webhook para:

### 🤖 Novo Bot Configurado
Quando um bot é adicionado ao sistema

### 🚀 Pull Iniciado
Quando um pedido de pull entra na fila

### ✅ Pull Finalizado
Quando um pull é concluído (com estatísticas)

### 🗑️ Usuário Excluído
Quando um usuário é removido por token inválido

**Cores Dinâmicas:**
- 🟢 Verde: Taxa de sucesso > 80%
- 🟡 Amarelo: Taxa de sucesso 50-80%
- 🔴 Vermelho: Taxa de sucesso < 50%

---

## 🖥️ Logs do Console

O sistema exibe logs detalhados e formatados:

```
============================================================
🚀 INICIANDO PULL DE MEMBROS
============================================================
📋 Pedido ID: pedido_1234567890_abc123
🤖 Bot ID: 987654321
🏠 Guild ID: 123456789
📊 Quantidade solicitada: 50
⏰ Iniciado em: 02/02/2026 10:30:00
============================================================

[1/50] 👤 Processando usuário: 111111111
[1/50] ✅ SUCESSO: Usuário 111111111 adicionado ao servidor!

[2/50] 👤 Processando usuário: 222222222
[2/50] 🚫 LIMITE ATINGIDO: Usuário já está em 100 servidores!
```

### Tipos de Erros Detectados

| Emoji | Descrição |
|-------|-----------|
| 🚫 | Limite de 100 servidores |
| 🔨 | Usuário banido |
| 🔒 | Sem permissão |
| 🔍 | Não encontrado |
| ⏱️ | Rate limit |
| 🤖 | Captcha necessário |
| 🗑️ | Usuário excluído |

---

## 📊 Estrutura de Arquivos

```
ilusion-auth02-api/
├── server.js                    # Servidor principal
├── config.json                  # Configuração de webhooks
├── config.example.json          # Exemplo de configuração
├── package.json                 # Dependências
├── database/
│   ├── configauth02api.json    # Configurações dos bots
│   ├── users.json              # Usuários verificados
│   ├── pedidos.json            # Histórico de pulls
│   ├── estoque.json            # (seu uso)
│   └── revenda.json            # (seu uso)
├── public/
│   ├── sucesso.html            # Página de sucesso
│   └── erro.html               # Página de erro
├── routes/
│   └── auth.js                 # Rotas de autenticação
└── docs/
    ├── API_DOCUMENTATION.md    # Documentação completa
    ├── CONFIGURACAO_WEBHOOK.md # Guia de webhooks
    ├── CHANGELOG.md            # Histórico de versões
    └── README.md               # Este arquivo
```

---

## 🔒 Segurança

- Autenticação via header para endpoints sensíveis
- Validação de tokens do Discord
- Rate limiting integrado
- Logs de IP e geolocalização
- Refresh automático de tokens

---

## 🚀 Deploy

### Recomendações

1. **Variáveis de Ambiente:**
   - Configure `PORT` para a porta do servidor
   - Use variáveis de ambiente para tokens sensíveis

2. **HTTPS:**
   - Use sempre HTTPS em produção
   - Configure certificado SSL

3. **Backup:**
   - Configure backups automáticos do banco de dados
   - Monitore o tamanho dos arquivos

4. **Monitoramento:**
   - Configure webhooks para receber alertas
   - Monitore logs do console

---

## 🆘 Suporte

### Problemas Comuns

**Webhook não envia:**
- Verifique se a URL está correta em `config.json`
- Teste a URL manualmente com curl
- Veja os logs do console

**Pull não funciona:**
- Verifique se o bot está no servidor
- Confirme as permissões do bot
- Veja se há membros disponíveis

**Token expirado:**
- O sistema renova automaticamente (3 tentativas)
- Se falhar, o usuário é excluído

### Contato

Para suporte técnico, entre em contato com a equipe Gama Apps.

---

## 📝 Licença

Este projeto é propriedade da **Gama Apps**.

---

## 🎯 Roadmap

- [ ] Dashboard web para gerenciamento
- [ ] Estatísticas em tempo real
- [ ] API de analytics
- [ ] Suporte a múltiplos idiomas
- [ ] Sistema de rate limiting customizável

---

**Desenvolvido por:** Gama Apps  
**Versão:** 1.2.0  
**Última Atualização:** 03 de Fevereiro de 2026

---

## ⭐ Features em Destaque

### 🎨 Embeds Personalizáveis
Configure cores, ícones e nomes do sistema

### 🔄 Sistema de Fila Inteligente
Processa pulls de forma assíncrona e eficiente

### 📊 Estatísticas Detalhadas
Taxa de sucesso, logs completos e histórico

### 🗑️ Auto-Limpeza
Remove automaticamente usuários com tokens inválidos

### 🚀 Pronto para Produção
Sistema robusto e testado em produção

---

**Comece agora:** `npm install && npm start`
