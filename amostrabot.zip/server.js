const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const requestIp = require("request-ip");
const axios = require('axios');
const geoip = require('geoip-lite');
const UAParser = require('ua-parser-js');
const app = express();

// ==================== SISTEMA DE RATE LIMITING ====================
const rateLimitMap = new Map();

function checkRateLimit(ip, endpoint, maxRequests = 5, windowMs = 60000) {
    const key = `${ip}:${endpoint}`;
    const now = Date.now();
    
    if (!rateLimitMap.has(key)) {
        rateLimitMap.set(key, { count: 1, resetTime: now + windowMs });
        return { allowed: true, remaining: maxRequests - 1 };
    }
    
    const record = rateLimitMap.get(key);
    
    // Reset se a janela expirou
    if (now > record.resetTime) {
        rateLimitMap.set(key, { count: 1, resetTime: now + windowMs });
        return { allowed: true, remaining: maxRequests - 1 };
    }
    
    // Incrementa contador
    record.count++;
    
    if (record.count > maxRequests) {
        const retryAfter = Math.ceil((record.resetTime - now) / 1000);
        return { allowed: false, retryAfter };
    }
    
    return { allowed: true, remaining: maxRequests - record.count };
}

// Limpa registros antigos a cada 5 minutos
setInterval(() => {
    const now = Date.now();
    for (const [key, record] of rateLimitMap.entries()) {
        if (now > record.resetTime) {
            rateLimitMap.delete(key);
        }
    }
}, 300000);
// ==================== FIM SISTEMA DE RATE LIMITING ====================

// ==================== SISTEMA DE FILA PARA PULLS ====================
const filaPulls = {
    pedidos: new Map(),     // Armazena os pedidos { id: { status, progress, ... } }
    fila: [],               // Fila de pedidos pendentes
    processando: false,     // Flag para controle de processamento
    delayEntrePulls: 1500   // Delay entre cada pull em ms (1.5s)
};

// Gera ID único para o pedido
function gerarPedidoId() {
    return `pedido_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Adiciona pedido na fila
function adicionarNaFila(dadosPedido) {
    const pedidoId = gerarPedidoId();
    const pedido = {
        id: pedidoId,
        status: 'em_fila',      // em_fila, em_andamento, concluido, falhou
        progresso: 0,
        total: dadosPedido.quantidade,
        sucessos: 0,
        falhas: 0,
        guild_id: dadosPedido.guild_id,
        bot_id: dadosPedido.bot_id,
        criado_em: new Date().toISOString(),
        iniciado_em: null,
        concluido_em: null,
        erro: null,
        logs: []
    };
    
    filaPulls.pedidos.set(pedidoId, pedido);
    filaPulls.fila.push(pedidoId);
    
    // Inicia processamento se não estiver rodando
    processarFila();
    
    return pedidoId;
}

// Processa a fila
async function processarFila() {
    if (filaPulls.processando || filaPulls.fila.length === 0) return;
    
    filaPulls.processando = true;
    
    while (filaPulls.fila.length > 0) {
        const pedidoId = filaPulls.fila.shift();
        const pedido = filaPulls.pedidos.get(pedidoId);
        
        if (!pedido) continue;
        
        pedido.status = 'em_andamento';
        pedido.iniciado_em = new Date().toISOString();
        
        try {
            await executarPull(pedido);
            pedido.status = 'concluido';
            pedido.concluido_em = new Date().toISOString();
            
            // Envia log de pull finalizado
            await logPullFinalizado(pedido);
        } catch (error) {
            pedido.status = 'falhou';
            pedido.erro = error.message;
            pedido.concluido_em = new Date().toISOString();
            
            // Envia log de pull finalizado com erro
            await logPullFinalizado(pedido);
        }
    }
    
    filaPulls.processando = false;
}

// Executa o pull de membros
async function executarPull(pedido) {

    const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
    const configBot = allBotsConfig[pedido.bot_id];
    
    if (!configBot || !configBot.token) {
        console.error(`❌ ERRO CRÍTICO: Bot ${pedido.bot_id} não configurado.`);
        throw new Error("Bot não configurado.");
    }
    
    let allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8') || '{}');
    const botUsers = allUsers[pedido.bot_id];
    
    if (!botUsers) {
        console.error(`❌ ERRO: Bot ${pedido.bot_id} não possui membros salvos.`);
        throw new Error("Bot não possui membros salvos.");
    }
    
    const userIDs = Object.keys(botUsers);
    const qtdParaPuxar = Math.min(pedido.total, userIDs.length);
    pedido.total = qtdParaPuxar;
    
    if (qtdParaPuxar === 0) {
        console.error(`❌ ERRO: Nenhum membro disponível para pull.`);
        throw new Error("Nenhum membro disponível.");
    }
    
    // Envia log de pull iniciado
    await logPullIniciado(pedido, userIDs.length);
    
    const forceJoin = async (userId, token) => {
        return axios.put(
            `https://discord.com/api/v10/guilds/${pedido.guild_id}/members/${userId}`,
            { access_token: token }, 
            { headers: { Authorization: `Bot ${configBot.token.trim()}`, 'Content-Type': 'application/json' } }
        );
    };
    
    for (let i = 0; i < qtdParaPuxar; i++) {
        const userId = userIDs[i];
        let userData = botUsers[userId];
        const progresso = `[${i + 1}/${qtdParaPuxar}]`;
        
        try {
            await forceJoin(userId, userData.access_token);
            pedido.sucessos++;
            pedido.logs.push({ user: userId, status: 'sucesso', time: new Date().toISOString() });
        } catch (err) {
            const errorCode = err.response?.status;
            const errorMessage = err.response?.data?.message || err.message;
            const errorData = err.response?.data;
            
            // Tenta refresh do token se expirado (até 3 tentativas)
            if (errorCode === 401 && userData.refresh_token) {
                let tokenRenovado = false;
                let novoAccessToken = null;
                const maxTentativas = 3;
                
                for (let tentativa = 1; tentativa <= maxTentativas; tentativa++) {
                    try {
                        
                        const params = new URLSearchParams();
                        params.append('client_id', String(configBot.bot_id));
                        params.append('client_secret', String(configBot.secret));
                        params.append('grant_type', 'refresh_token');
                        params.append('refresh_token', String(userData.refresh_token));

                        const refreshRes = await axios.post('https://discord.com/api/v10/oauth2/token', params.toString(), {
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                        });

                        const { access_token, refresh_token } = refreshRes.data;
                        allUsers[pedido.bot_id][userId].access_token = access_token;
                        allUsers[pedido.bot_id][userId].refresh_token = refresh_token;
                        fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));

                        tokenRenovado = true;
                        novoAccessToken = access_token;
                        break;
                        
                    } catch (refreshErr) {
                        const refreshErrorCode = refreshErr.response?.status;
                        const refreshErrorMsg = refreshErr.response?.data?.message || refreshErr.message;
                        const refreshErrorData = refreshErr.response?.data;
                        
                        console.error(`${progresso} ⚠️  Tentativa ${tentativa}/${maxTentativas} falhou (${refreshErrorCode}): ${refreshErrorMsg}`);
                        
                        // Se for erro de invalid_grant, não adianta tentar novamente
                        if (refreshErrorData?.error === 'invalid_grant' || refreshErrorCode === 400) {
                            console.error(`${progresso} 🚫 Refresh token inválido. Não é possível renovar.`);
                            break;
                        }
                        
                        // Aguarda 1 segundo antes da próxima tentativa
                        if (tentativa < maxTentativas) {
                            await new Promise(resolve => setTimeout(resolve, 1000));
                        }
                    }
                }
                
                // Se conseguiu renovar, tenta adicionar o usuário
                if (tokenRenovado && novoAccessToken) {
                    try {
                        await forceJoin(userId, novoAccessToken);
                        pedido.sucessos++;
                        pedido.logs.push({ user: userId, status: 'sucesso_apos_refresh', time: new Date().toISOString() });
                    } catch (joinErr) {
                        const joinErrorCode = joinErr.response?.status;
                        const joinErrorMsg = joinErr.response?.data?.message || joinErr.message;
                        
                        pedido.falhas++;
                        pedido.logs.push({ user: userId, status: 'falha_apos_refresh', erro: joinErrorMsg, time: new Date().toISOString() });
                        console.error(`${progresso} ❌ FALHA: Erro ao adicionar após renovação (${joinErrorCode}): ${joinErrorMsg}`);
                    }
                } else {
                    // Não conseguiu renovar após 3 tentativas - EXCLUIR USUÁRIO
                    console.error(`${progresso} 🗑️  EXCLUINDO USUÁRIO: Não foi possível renovar token após ${maxTentativas} tentativas`);
                    
                    // Remove o usuário do banco
                    delete allUsers[pedido.bot_id][userId];
                    fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));
                    
                    pedido.falhas++;
                    pedido.logs.push({ 
                        user: userId, 
                        status: 'excluido', 
                        motivo: 'token_invalido_apos_3_tentativas',
                        time: new Date().toISOString() 
                    });
                    
                    // Envia log de usuário excluído
                    await logUsuarioExcluido(userId, pedido.bot_id, 'token_invalido_apos_3_tentativas');
                }
            } else if (errorCode === 401 && !userData.refresh_token) {
                // Não tem refresh_token - EXCLUIR USUÁRIO
                console.error(`${progresso} 🗑️  EXCLUINDO USUÁRIO: Token expirado e sem refresh_token disponível`);
                
                delete allUsers[pedido.bot_id][userId];
                fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));
                
                pedido.falhas++;
                pedido.logs.push({ 
                    user: userId, 
                    status: 'excluido', 
                    motivo: 'sem_refresh_token',
                    time: new Date().toISOString() 
                });
                
                // Envia log de usuário excluído
                await logUsuarioExcluido(userId, pedido.bot_id, 'sem_refresh_token');
            } else if (errorCode === 204) {
                pedido.sucessos++;
                pedido.logs.push({ user: userId, status: 'ja_membro', time: new Date().toISOString() });
            } else if (errorCode === 403) {
                // Verifica se é token inválido (usuário desautorizou)
                if (errorMessage?.includes('Invalid OAuth2 access token')) {
                    // Tenta renovar o token se tiver refresh_token
                    if (userData.refresh_token) {
                        let tokenRenovado = false;
                        let novoAccessToken = null;
                        const maxTentativas = 3;
                        
                        for (let tentativa = 1; tentativa <= maxTentativas; tentativa++) {
                            try {
                                
                                const params = new URLSearchParams();
                                params.append('client_id', String(configBot.bot_id));
                                params.append('client_secret', String(configBot.secret));
                                params.append('grant_type', 'refresh_token');
                                params.append('refresh_token', String(userData.refresh_token));

                                const refreshRes = await axios.post('https://discord.com/api/v10/oauth2/token', params.toString(), {
                                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                                });

                                const { access_token, refresh_token } = refreshRes.data;
                                allUsers[pedido.bot_id][userId].access_token = access_token;
                                allUsers[pedido.bot_id][userId].refresh_token = refresh_token;
                                fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));

                                tokenRenovado = true;
                                novoAccessToken = access_token;
                                break;
                                
                            } catch (refreshErr) {
                                const refreshErrorCode = refreshErr.response?.status;
                                const refreshErrorMsg = refreshErr.response?.data?.message || refreshErr.message;
                                const refreshErrorData = refreshErr.response?.data;
                                
                                console.error(`${progresso} ⚠️  Tentativa ${tentativa}/${maxTentativas} falhou (${refreshErrorCode}): ${refreshErrorMsg}`);
                                
                                if (refreshErrorData?.error === 'invalid_grant' || refreshErrorCode === 400) {
                                    console.error(`${progresso} 🚫 Refresh token inválido. Não é possível renovar.`);
                                    break;
                                }
                                
                                if (tentativa < maxTentativas) {
                                    await new Promise(resolve => setTimeout(resolve, 1000));
                                }
                            }
                        }
                        
                        // Se conseguiu renovar, tenta adicionar o usuário
                        if (tokenRenovado && novoAccessToken) {
                            try {
                                await forceJoin(userId, novoAccessToken);
                                pedido.sucessos++;
                                pedido.logs.push({ user: userId, status: 'sucesso_apos_refresh', time: new Date().toISOString() });
                            } catch (joinErr) {
                                const joinErrorCode = joinErr.response?.status;
                                const joinErrorMsg = joinErr.response?.data?.message || joinErr.message;
                                
                                pedido.falhas++;
                                pedido.logs.push({ user: userId, status: 'falha_apos_refresh', erro: joinErrorMsg, time: new Date().toISOString() });
                                console.error(`${progresso} ❌ FALHA: Erro ao adicionar após renovação (${joinErrorCode}): ${joinErrorMsg}`);
                            }
                        } else {
                            // Não conseguiu renovar - EXCLUIR USUÁRIO
                            console.error(`${progresso} 🗑️  EXCLUINDO USUÁRIO: Não foi possível renovar token após ${maxTentativas} tentativas`);
                            
                            delete allUsers[pedido.bot_id][userId];
                            fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));
                            
                            pedido.falhas++;
                            pedido.logs.push({ 
                                user: userId, 
                                status: 'excluido', 
                                motivo: 'desautorizou_app',
                                time: new Date().toISOString() 
                            });
                            
                            await logUsuarioExcluido(userId, pedido.bot_id, 'desautorizou_app');
                        }
                    } else {
                        // Não tem refresh_token - EXCLUIR USUÁRIO
                        console.error(`${progresso} 🗑️  EXCLUINDO USUÁRIO: Token inválido e sem refresh_token disponível`);
                        
                        delete allUsers[pedido.bot_id][userId];
                        fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));
                        
                        pedido.falhas++;
                        pedido.logs.push({ 
                            user: userId, 
                            status: 'excluido', 
                            motivo: 'sem_refresh_token',
                            time: new Date().toISOString() 
                        });
                        
                        await logUsuarioExcluido(userId, pedido.bot_id, 'sem_refresh_token');
                    }
                } else {
                    // Outros erros 403
                    pedido.falhas++;
                    pedido.logs.push({ user: userId, status: 'falha', erro: errorMessage, code: errorCode, time: new Date().toISOString() });
                    
                    if (errorData?.code === 30001 || errorMessage?.includes('Maximum number of guilds reached')) {
                        console.error(`${progresso} 🚫 LIMITE ATINGIDO: Usuário ${userId} já está em 100 servidores! (Limite do Discord)`);
                    } else if (errorMessage?.includes('Missing Permissions') || errorMessage?.includes('Missing Access')) {
                        console.error(`${progresso} 🔒 PERMISSÃO NEGADA: Bot não tem permissão para adicionar ${userId}`);
                    } else if (errorMessage?.includes('banned')) {
                        console.error(`${progresso} 🔨 BANIDO: Usuário ${userId} está banido do servidor`);
                    } else {
                        console.error(`${progresso} ❌ ERRO 403: ${errorMessage}`);
                    }
                }
            } else if (errorCode === 404) {
                pedido.falhas++;
                pedido.logs.push({ user: userId, status: 'falha', erro: errorMessage, code: errorCode, time: new Date().toISOString() });
                console.error(`${progresso} 🔍 NÃO ENCONTRADO: Usuário ${userId} ou servidor não existe`);
            } else if (errorCode === 429) {
                pedido.falhas++;
                pedido.logs.push({ user: userId, status: 'falha', erro: 'Rate Limited', code: errorCode, time: new Date().toISOString() });
                const retryAfter = err.response?.headers['retry-after'] || 'desconhecido';
                console.error(`${progresso} ⏱️  RATE LIMIT: Aguarde ${retryAfter}s antes de tentar novamente`);
            } else if (errorCode === 400) {
                pedido.falhas++;
                pedido.logs.push({ user: userId, status: 'falha', erro: errorMessage, code: errorCode, time: new Date().toISOString() });
                
                if (errorMessage?.includes('captcha')) {
                    console.error(`${progresso} 🤖 CAPTCHA: Usuário ${userId} precisa resolver captcha`);
                } else if (errorMessage?.includes('invalid')) {
                    console.error(`${progresso} ⚠️  TOKEN INVÁLIDO: Access token do usuário ${userId} é inválido`);
                } else {
                    console.error(`${progresso} ❌ ERRO 400: ${errorMessage}`);
                }
            } else {
                pedido.falhas++;
                pedido.logs.push({ user: userId, status: 'falha', erro: errorMessage, code: errorCode, time: new Date().toISOString() });
                console.error(`${progresso} ❌ ERRO ${errorCode || 'DESCONHECIDO'}: ${errorMessage}`);
            }
        }
        
        pedido.progresso++;
        
        // Delay entre pulls para evitar rate limit
        await new Promise(resolve => setTimeout(resolve, filaPulls.delayEntrePulls));
    }
    
    // Verifica se deve sair do servidor após o pull
    if (configBot.guild_id && configBot.guild_id === pedido.guild_id) {
    } else {
        try {
            await axios.delete(`https://discord.com/api/v10/users/@me/guilds/${pedido.guild_id}`, {
                headers: { 'Authorization': `Bot ${configBot.token.trim()}` }
            });
            
            // Envia log de bot saindo do servidor
            await logBotSaiuServidor(pedido, pedido.guild_id, configBot.bot_name || 'Bot');
        } catch (leaveError) {
            console.error(`❌ Erro ao sair do servidor: ${leaveError.message}`);
        }
    }
    
    // Salva histórico de pedidos
    salvarPedidosJSON();
}

// Salva pedidos no arquivo JSON
function salvarPedidosJSON() {
    const pedidosPath = path.join(__dirname, 'database', 'pedidos.json');
    const pedidosArray = Array.from(filaPulls.pedidos.values());
    fs.writeFileSync(pedidosPath, JSON.stringify(pedidosArray, null, 4));
}

// Carrega pedidos do arquivo JSON ao iniciar
function carregarPedidosJSON() {
    const pedidosPath = path.join(__dirname, 'database', 'pedidos.json');
    if (fs.existsSync(pedidosPath)) {
        try {
            const pedidosArray = JSON.parse(fs.readFileSync(pedidosPath, 'utf-8'));
            pedidosArray.forEach(pedido => {
                filaPulls.pedidos.set(pedido.id, pedido);
            });
        } catch (e) {
            // Erro ao carregar pedidos.json
        }
    }
}

// Carrega pedidos ao iniciar o servidor
carregarPedidosJSON();
// ==================== FIM SISTEMA DE FILA ====================

// ==================== SISTEMA DE ROTAÇÃO DE USERS.JSON ====================
const MAX_FILE_SIZE_MB = 5; // Tamanho máximo em MB antes de criar novo arquivo
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

// Verifica o tamanho do arquivo users.json
function verificarTamanhoUsers() {
    if (!fs.existsSync(usersPath)) return { precisaRotacionar: false, tamanhoAtual: 0 };
    
    const stats = fs.statSync(usersPath);
    const tamanhoMB = (stats.size / (1024 * 1024)).toFixed(2);
    
    return {
        precisaRotacionar: stats.size >= MAX_FILE_SIZE_BYTES,
        tamanhoAtual: stats.size,
        tamanhoMB: tamanhoMB
    };
}

// Rotaciona o arquivo users.json criando um backup
function rotacionarUsersJSON() {
    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
        const hora = new Date().toISOString().split('T')[1].split('.')[0].replace(/:/g, '-');
        const backupFileName = `users_backup_${timestamp}_${hora}.json`;
        const backupPath = path.join(__dirname, 'database', backupFileName);
        
        // Copia o arquivo atual para backup
        if (fs.existsSync(usersPath)) {
            const usersData = fs.readFileSync(usersPath, 'utf-8');
            fs.writeFileSync(backupPath, usersData);
            
            const stats = fs.statSync(backupPath);
            const tamanhoMB = (stats.size / (1024 * 1024)).toFixed(2);
            
            // Cria novo users.json vazio
            fs.writeFileSync(usersPath, '{}');
            
            return {
                sucesso: true,
                backup: backupFileName,
                tamanho: tamanhoMB
            };
        }
    } catch (error) {
        console.error('❌ Erro ao rotacionar users.json:', error);
        return { sucesso: false, erro: error.message };
    }
}

// Verifica e rotaciona se necessário antes de salvar novos usuários
function salvarUsuarioComRotacao(botId, userId, userData) {
    // Verifica se precisa rotacionar
    const { precisaRotacionar, tamanhoMB } = verificarTamanhoUsers();
    
    if (precisaRotacionar) {
        rotacionarUsersJSON();
    }
    
    // Carrega ou cria estrutura
    let usersDB = {};
    if (fs.existsSync(usersPath)) {
        try { 
            usersDB = JSON.parse(fs.readFileSync(usersPath, 'utf-8')); 
        } catch (e) { 
            usersDB = {}; 
        }
    }
    
    // Adiciona o novo usuário
    if (!usersDB[botId]) usersDB[botId] = {};
    usersDB[botId][userId] = userData;
    
    // Salva
    fs.writeFileSync(usersPath, JSON.stringify(usersDB, null, 4));
    
    return { sucesso: true };
}

// Lista todos os backups disponíveis
function listarBackups() {
    const databasePath = path.join(__dirname, 'database');
    const arquivos = fs.readdirSync(databasePath);
    
    const backups = arquivos
        .filter(file => file.startsWith('users_backup_') && file.endsWith('.json'))
        .map(file => {
            const filePath = path.join(databasePath, file);
            const stats = fs.statSync(filePath);
            return {
                nome: file,
                tamanho: (stats.size / (1024 * 1024)).toFixed(2) + 'MB',
                criado_em: stats.birthtime,
                path: filePath
            };
        })
        .sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em));
    
    return backups;
}
// ==================== FIM SISTEMA DE ROTAÇÃO ====================

// ==================== SISTEMA DE LOGS VIA WEBHOOK ====================
// Carrega configurações do webhook
function carregarConfig() {
    try {
        if (fs.existsSync(configPath)) {
            const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
            return config;
        }
        return null;
    } catch (error) {
        console.error('⚠️ Erro ao carregar config.json:', error.message);
        return null;
    }
}

// Envia embed de log via webhook
async function enviarLogWebhook(embed) {
    try {
        const config = carregarConfig();
        
        if (!config || !config.webhook_logs || config.webhook_logs === 'COLOQUE_SEU_WEBHOOK_AQUI') {
            return;
        }
        
        await axios.post(config.webhook_logs, {
            embeds: [embed]
        });
    } catch (error) {
        console.error('❌ Erro ao enviar log para webhook:', error.message);
    }
}

// Log de novo bot configurado
async function logBotConfigurado(botData) {
    const config = carregarConfig();
    const corEmbed = config?.cor_embed || 8134125;
    
    const embed = {
        title: '🤖 Novo Bot Configurado',
        description: `Um novo bot foi configurado no sistema **${config?.nome_sistema || 'Ilusion Auth02 API'}**.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Bot ID: \`${botData.bot_id}\`\n- Nome do Bot: \`${botData.bot_name}\`\n- Admin ID: <@${botData.admin_id}>\n- Link de Autenticação: [Clique aqui](${botData.auth_link})`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de pull iniciado
async function logPullIniciado(pedido, qtdMembros) {
    const config = carregarConfig();
    const corEmbed = config?.cor_embed || 8134125;
    
    const embed = {
        title: '🚀 Pull de Membros Iniciado',
        description: `Um novo pedido de pull foi adicionado à fila.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Pedido ID: \`${pedido.id}\`\n- Bot ID: \`${pedido.bot_id}\`\n- Guild ID: \`${pedido.guild_id}\`\n- Quantidade: \`${pedido.total}\` membros\n- Membros Disponíveis: \`${qtdMembros}\` no banco\n- Iniciado em: <t:${Math.floor(new Date(pedido.criado_em).getTime() / 1000)}:F>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de pull finalizado
async function logPullFinalizado(pedido) {
    const config = carregarConfig();
    const taxaSucesso = pedido.total > 0 ? ((pedido.sucessos / pedido.total) * 100).toFixed(1) : 0;
    
    // Define cor baseada na taxa de sucesso
    let corEmbed = 0x22c55e; // Verde (sucesso)
    if (taxaSucesso < 50) {
        corEmbed = 0xef4444; // Vermelho (falha)
    } else if (taxaSucesso < 80) {
        corEmbed = 0xf59e0b; // Amarelo (parcial)
    }
    
    let infoValue = `- Pedido ID: \`${pedido.id}\`\n- Bot ID: \`${pedido.bot_id}\`\n- Guild ID: \`${pedido.guild_id}\`\n- Total Processado: \`${pedido.total}\` membros\n- Sucessos: \`${pedido.sucessos}\`\n- Falhas: \`${pedido.falhas}\`\n- Taxa de Sucesso: \`${taxaSucesso}%\`\n- Iniciado em: <t:${Math.floor(new Date(pedido.iniciado_em).getTime() / 1000)}:R>\n- Finalizado em: <t:${Math.floor(new Date(pedido.concluido_em).getTime() / 1000)}:R>`;
    
    // Adiciona erro se houver
    if (pedido.erro) {
        infoValue += `\n- Erro: \`${pedido.erro}\``;
    }
    
    const embed = {
        title: pedido.status === 'concluido' ? '✅ Pull Finalizado com Sucesso' : '❌ Pull Finalizado com Erros',
        description: `O pedido de pull foi concluído.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: infoValue,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de usuário excluído
async function logUsuarioExcluido(userId, botId, motivo) {
    const config = carregarConfig();
    const corEmbed = 0xef4444; // Vermelho
    
    const motivosTexto = {
        'token_invalido_apos_3_tentativas': '`Token inválido após 3 tentativas de renovação`',
        'sem_refresh_token': '`Token expirado sem refresh_token disponível`',
        'desautorizou_app': '`Usuário desautorizou o aplicativo OAuth2`'
    };
    
    const embed = {
        title: '🗑️ Usuário Excluído do Banco',
        description: `Um usuário foi removido automaticamente do banco de dados.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- User ID: \`${userId}\`\n- Bot ID: \`${botId}\`\n- Motivo: ${motivosTexto[motivo] || '`Motivo desconhecido`'}\n- Excluído em: <t:${Math.floor(Date.now() / 1000)}:F>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de bot saindo do servidor
async function logBotSaiuServidor(pedido, guildId, botName) {
    const config = carregarConfig();
    const corEmbed = 0xf59e0b; // Amarelo/Laranja
    
    const embed = {
        title: '🚪 Bot Saiu do Servidor',
        description: `O bot saiu automaticamente do servidor após concluir o pull de membros.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Bot: \`${botName}\`\n- Guild ID: \`${guildId}\`\n- Pedido ID: \`${pedido.id}\`\n- Membros Adicionados: \`${pedido.sucessos}\`\n- Falhas: \`${pedido.falhas}\`\n- Saiu em: <t:${Math.floor(Date.now() / 1000)}:F>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de gift criado (webhook global)
async function logGiftCriado(giftData) {
    const config = carregarConfig();
    const corEmbed = config?.cor_embed || 8134125;
    
    const embed = {
        title: '🎁 Novo Gift Criado',
        description: `Um novo gift de membros foi criado no sistema.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Código: \`${giftData.codigo}\`\n- Bot: \`${giftData.bot_name}\`\n- Quantidade: \`${giftData.quantidade}\` membros\n- Criado por: ${giftData.criado_por}\n- Link de Resgate: [Clique aqui](${giftData.link})\n- Criado em: <t:${Math.floor(new Date(giftData.criado_em).getTime() / 1000)}:F>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de gift resgatado (webhook global)
async function logGiftResgatado(giftData, guildId) {
    const config = carregarConfig();
    const corEmbed = 0x22c55e; // Verde
    
    const embed = {
        title: '🎉 Gift Resgatado',
        description: `Um gift foi resgatado e o pull de membros foi iniciado.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Código: \`${giftData.codigo}\`\n- Bot: \`${giftData.bot_name}\`\n- Quantidade: \`${giftData.quantidade}\` membros\n- Servidor: \`${guildId}\`\n- Pedido ID: \`${giftData.pedido_id}\`\n- Resgatado em: <t:${Math.floor(new Date(giftData.resgatado_em).getTime() / 1000)}:F>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Log de gift resgatado (webhook do bot específico)
async function logGiftResgatadoBot(giftData, guildId, configBot) {
    if (!configBot.webhook_logs) return;
    
    const corEmbed = 0x22c55e; // Verde
    
    const embed = {
        title: '🎉 Gift Resgatado no Seu Bot',
        description: `Um gift do bot **${configBot.bot_name}** foi resgatado.`,
        color: corEmbed,
        fields: [
            {
                name: '**Informações**',
                value: `- Código do Gift: \`${giftData.codigo}\`\n- Quantidade de Membros: \`${giftData.quantidade}\` membros\n- Servidor de Destino: \`${guildId}\`\n- ID do Pedido: \`${giftData.pedido_id}\`\n- Resgatado em: <t:${Math.floor(new Date(giftData.resgatado_em).getTime() / 1000)}:F>\n- Informação: Os membros estão sendo puxados para o servidor. Você pode acompanhar o progresso através do ID do pedido.`,
                inline: false
            }
        ],
        footer: {
            text: `Gama Apps • Bot: ${configBot.bot_name}`
        },
        timestamp: new Date().toISOString()
    };
    
    try {
        await axios.post(configBot.webhook_logs, {
            embeds: [embed]
        });
    } catch (error) {
        console.error('❌ Erro ao enviar log para webhook do bot:', error.message);
    }
}
// ==================== FIM SISTEMA DE LOGS VIA WEBHOOK ====================

// Configurações Iniciais
app.use(cors());
app.use(express.json());
app.use(requestIp.mw());
const usersDBPath = path.join(__dirname, 'database', 'users.json');
// 📂 Caminhos das Databases (Pasta 'database' no site)
const dbPathAuth = path.join(__dirname, 'database', 'configauth02api.json');
const usersPath = path.join(__dirname, 'database', 'users.json');
const configPath = path.join(__dirname, 'config.json');
// Faz com que /sucesso aponte para sucesso.html automaticamente
app.use(express.static('public', { extensions: ['html'] }));

// Rota dinâmica para página de autenticação com código aleatório
app.get('/authentication=:authCode', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'sucesso.html'));
});

// Rota para página de gift
app.get('/gift/:codigo', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'gift.html'));
});

// Garantir que a pasta database existe
if (!fs.existsSync(path.join(__dirname, 'database'))) {
    fs.mkdirSync(path.join(__dirname, 'database'));
}

// 🌐 Servir a página de sucesso (coloque o sucesso.html na pasta /public)
app.use(express.static(path.join(__dirname, 'public')));

app.get('/auth02/verify', async (req, res) => {
    // Pegamos o 'code' (autorização) e o 'state' (ID do Bot que veio no link)
    const { code, state } = req.query;
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || "127.0.0.1";
    const userAgent = req.headers['user-agent'];

    // Validações Iniciais
    if (!code) return res.status(400).send("Código ausente. Tente novamente.");
    if (!state) return res.status(400).send("ID do Bot (state) ausente. Use o link oficial do bot.");

    try {
        // 1. Carrega a Database de Configurações
        if (!fs.existsSync(dbPathAuth)) return res.status(500).send("Database de bots não encontrada.");
        const botsDB = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));

        // 2. Localiza o Bot exato usando o ID do 'state'
        const configBot = botsDB[state];
        if (!configBot) {
            console.error(`[AUTH ERROR] Bot ID ${state} não configurado.`);
            return res.status(404).send("Configuração para este bot não encontrada.");
        }

        // 3. Troca o Código pelo Access Token no Discord
        const params = new URLSearchParams({
            client_id: configBot.bot_id,
            client_secret: configBot.secret,
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: `https://gamacloud.camposcloud.app/auth02/verify`,
            scope: 'identify guilds.join'
        });

        let tokenResponse;
        try {
            tokenResponse = await axios.post('https://discord.com/api/v10/oauth2/token', params, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
        } catch (tokenError) {
            // Tratamento específico para código expirado ou inválido
            if (tokenError.response?.status === 400) {
                const errorData = tokenError.response.data;
                if (errorData.error === 'invalid_grant') {
                    return res.redirect('/erro.html?type=expired');
                }
            }
            throw tokenError; // Re-lança outros erros
        }

        const { access_token, refresh_token } = tokenResponse.data;

        // 4. Busca os dados do Usuário autenticado
        const userRes = await axios.get('https://discord.com/api/v10/users/@me', {
            headers: { 'Authorization': `Bearer ${access_token}` }
        });
        const userData = userRes.data;

        // 5. Salva na Database de Usuários com sistema de rotação automática
        const dadosUsuario = {
            id: userData.id,
            username: userData.username,
            access_token: access_token,
            refresh_token: refresh_token,
            ip: ip,
            data_verificacao: new Date().toISOString()
        };
        
        salvarUsuarioComRotacao(configBot.bot_id, userData.id, dadosUsuario);

        // 6. Lógica de Cargo (Atribuição Automática)
        let statusCargo = "❌ Não configurado";
        if (configBot.guild_id && configBot.token && configBot.role_id) {
            try {
                await axios.put(
                    `https://discord.com/api/v10/guilds/${configBot.guild_id}/members/${userData.id}/roles/${configBot.role_id}`,
                    {}, 
                    { headers: { 'Authorization': `Bot ${configBot.token.trim()}` } }
                );
                statusCargo = "✅ Atribuído com sucesso";
            } catch (roleError) {
                if (roleError.response?.status === 404) {
                    statusCargo = "⚠️ Usuário não está no servidor";
                } else {
                    statusCargo = `❌ Erro: ${roleError.response?.data?.message || "Sem permissão"}`;
                }
            }
        }

        // 7. Preparação para os Logs (Geolocalização e Idade da Conta)
        const createdAt = Number((BigInt(userData.id) >> 22n) + 1420070400000n);
        const idadeDias = Math.floor((Date.now() - createdAt) / (1000 * 60 * 60 * 24));
        const idadeConta = idadeDias > 365 ? `${(idadeDias / 365).toFixed(1)} anos` : `${idadeDias} dias`;
        
        const geo = geoip.lookup(ip);
        const localizacao = geo ? `${geo.city || 'Desconhecido'}, ${geo.country}` : "Brasil (Provável)";
        
        const parser = new UAParser(userAgent);
        const ua = parser.getResult();
        const dispositivo = `${ua.os.name || 'OS'} (${ua.browser.name || 'Browser'})`;

        // 8. Disparo do Webhook de Logs do Bot Específico
        if (configBot.webhook_logs) {
            const avatarUrl = userData.avatar ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/0.png`;
            
            await axios.post(configBot.webhook_logs, {
                embeds: [{
                    title: "✅ | Novo Usuário Verificado",
                    description: `O usuário **${userData.username}** passou pela verificação do bot **${configBot.bot_name}**.`,
                    color: 0x7c3aed, // Roxo Ilusion
                    thumbnail: { url: avatarUrl },
                    fields: [
                        { name: "👥 Usuário", value: `<@${userData.id}> (\`${userData.id}\`)`, inline: true },
                        { name: "🛰️ IP", value: `||${ip}||`, inline: true },
                        { name: "🛡️ Cargo", value: `\`${statusCargo}\``, inline: true },
                        { name: "📅 Idade da Conta", value: `\`${idadeConta}\``, inline: true },
                        { name: "🌍 Localização", value: `\`${localizacao}\``, inline: true },
                        { name: "💻 Dispositivo", value: `\`${dispositivo}\``, inline: false }
                    ],
                    footer: { text: `Gama Apps • Bot: ${configBot.bot_name}` },
                    timestamp: new Date()
                }]
            }).catch(() => {});
        }

        // 9. Redirecionamento Final para o Site
        const finalAvatar = userData.avatar ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/0.png`;
        
        // Busca informações do servidor (guild)
        let guildData = { name: 'Servidor', icon: null };
        if (configBot.guild_id) {
            try {
                const guildRes = await axios.get(`https://discord.com/api/v10/guilds/${configBot.guild_id}`, {
                    headers: { 'Authorization': `Bot ${configBot.token.trim()}` }
                });
                guildData.name = guildRes.data.name;
                if (guildRes.data.icon) {
                    guildData.icon = `https://cdn.discordapp.com/icons/${configBot.guild_id}/${guildRes.data.icon}.png`;
                }
            } catch (guildErr) {
                // Erro ao buscar dados do servidor
            }
        }
        
        const verificationData = {
            username: userData.username,
            avatar: finalAvatar,
            guild_name: guildData.name,
            guild_icon: guildData.icon,
            bot_name: configBot.bot_name
        };
        
        res.send(`<script>sessionStorage.setItem('temp_user', JSON.stringify(${JSON.stringify(verificationData)})); window.location.href = '/sucesso';</script>`);

    } catch (error) {
        console.error("❌ Erro na Verificação:", error.response?.data || error.message);
        
        // Redireciona para página de erro apropriada
        if (error.response?.data?.error === 'invalid_grant') {
            return res.redirect('/erro.html?type=expired');
        }
        
        return res.redirect('/erro.html?type=generic');
    }
});
// --- ROTA DE CONFIGURAÇÃO (O bot de vendas envia as chaves aqui) ---
app.post('/api/auth02/configurar', async (req, res) => {
    const { user_id, client_secret, token } = req.body;
    
    try {
        // 1. Validamos o Token e pegamos os dados reais do Bot no Discord
        const response = await axios.get('https://discord.com/api/v10/users/@me', {
            headers: { 'Authorization': `Bot ${token.trim()}` }
        });
        
        const botID = response.data.id;
        const redirectUri = encodeURIComponent("https://gamacloud.camposcloud.app/auth02/verify");
        
        // 2. GERAMOS O LINK AUTOMÁTICO COM STATE
        // O segredo está aqui: &state=${botID}
        const authLink = `https://discord.com/api/oauth2/authorize?client_id=${botID}&redirect_uri=${redirectUri}&response_type=code&scope=identify%20guilds.join&state=${botID}`;

        let botsDB = {};
        if (fs.existsSync(dbPathAuth)) {
            botsDB = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        }

        // 3. Salvamos na gaveta usando o ID do bot como chave
        botsDB[botID] = {
            ...(botsDB[botID] || {}), 
            bot_id: botID,
            bot_name: response.data.username,
            secret: client_secret.trim(),
            token: token.trim(),
            admin_id: user_id,
            auth_link: authLink // Agora o link já fica salvo pronto para uso
        };

        fs.writeFileSync(dbPathAuth, JSON.stringify(botsDB, null, 4));
        
        // Envia log de bot configurado
        await logBotConfigurado({
            bot_id: botID,
            bot_name: response.data.username,
            admin_id: user_id,
            auth_link: authLink
        });
        
        res.status(200).json({ 
            sucesso: true, 
            bot_id: botID,
            auth_link: authLink 
        });

    } catch (error) { 
        console.error("Erro ao configurar bot:", error.message);
        res.status(401).json({ sucesso: false, erro: "Token inválido ou falha na API do Discord" }); 
    }
});
// --- ROTA DE INFO (O bot consulta quantos membros tem) ---
app.get('/api/auth02/info/:botID', (req, res) => {
    const { botID } = req.params;
    if (!fs.existsSync(usersPath)) return res.json({ sucesso: true, membros: 0 });

    const allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
    const total = allUsers[botID] ? Object.keys(allUsers[botID]).length : 0;
    
    res.json({ sucesso: true, membros: total });
});
app.post('/api/auth02/pull', async (req, res) => {
    const { bot_id, guild_id, quantidade } = req.body;
    const authHeader = req.headers['authorization'];

    if (authHeader !== 'galaodamassa581') return res.status(403).json({ error: "Não autorizado" });

    if (!bot_id || !guild_id || !quantidade) {
        return res.status(400).json({ sucesso: false, erro: "Parâmetros ausentes (bot_id, guild_id ou quantidade)." });
    }

    try {
        // Valida se o bot existe
        if (!fs.existsSync(dbPathAuth)) return res.status(404).json({ message: "Configuração não encontrada." });
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[bot_id]; 
        
        if (!configBot) return res.status(404).json({ message: "Configuração para este Bot ID não encontrada." });
        if (!configBot.token) return res.status(400).json({ sucesso: false, erro: "Token do bot não configurado." });

        // Verifica se o bot está no servidor de destino
        try {
            const guildCheck = await axios.get(`https://discord.com/api/v10/guilds/${guild_id}`, {
                headers: { 'Authorization': `Bot ${configBot.token.trim()}` }
            });
        } catch (guildError) {
            if (guildError.response?.status === 403) {
                return res.status(403).json({ 
                    sucesso: false, 
                    erro: "Bot não está no servidor de destino ou não tem permissões.",
                    detalhes: "Adicione o bot ao servidor antes de fazer pulls."
                });
            } else if (guildError.response?.status === 404) {
                return res.status(404).json({ 
                    sucesso: false, 
                    erro: "Servidor não encontrado.",
                    detalhes: "Verifique se o guild_id está correto."
                });
            } else if (guildError.response?.status === 401) {
                return res.status(401).json({ 
                    sucesso: false, 
                    erro: "Token do bot inválido.",
                    detalhes: "Reconfigure o bot com um token válido."
                });
            }
            throw guildError;
        }

        // Verifica se há membros disponíveis
        if (!fs.existsSync(usersPath)) return res.status(404).json({ message: "Arquivo users.json não encontrado." });
        let allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8') || '{}');
        const botUsers = allUsers[bot_id];
        
        if (!botUsers || Object.keys(botUsers).length === 0) {
            return res.status(400).json({ sucesso: false, erro: "Nenhum membro disponível para este bot." });
        }

        // Adiciona na fila
        const pedidoId = adicionarNaFila({
            guild_id,
            quantidade: parseInt(quantidade),
            bot_id
        });

        const posicaoFila = filaPulls.fila.length;
        const estimativaSegundos = Math.ceil((parseInt(quantidade) * filaPulls.delayEntrePulls) / 1000);

        res.json({ 
            sucesso: true,
            pedido_id: pedidoId,
            mensagem: "Pull adicionado na fila com sucesso!",
            posicao_fila: posicaoFila,
            quantidade_solicitada: parseInt(quantidade),
            estimativa_segundos: estimativaSegundos,
            endpoint_status: `/api/auth02/pedido/${pedidoId}`
        });

    } catch (error) {
        console.error("❌ Erro ao adicionar pull na fila:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// GET /api/auth02/pedido/:pedidoId - Verifica status de um pedido específico
app.get('/api/auth02/pedido/:pedidoId', (req, res) => {
    const { pedidoId } = req.params;
    const pedido = filaPulls.pedidos.get(pedidoId);

    if (!pedido) {
        return res.status(404).json({ sucesso: false, erro: "Pedido não encontrado." });
    }

    const porcentagem = pedido.total > 0 ? Math.round((pedido.progresso / pedido.total) * 100) : 0;

    // Traduz status para português
    let statusTexto = '';
    switch(pedido.status) {
        case 'em_fila':
            statusTexto = 'Em Fila';
            break;
        case 'em_andamento':
            statusTexto = 'Em Andamento';
            break;
        case 'concluido':
            statusTexto = 'Concluído';
            break;
        case 'falhou':
            statusTexto = 'Falhou';
            break;
        default:
            statusTexto = pedido.status;
    }

    res.json({
        sucesso: true,
        pedido: {
            id: pedido.id,
            status: pedido.status,
            status_texto: statusTexto,
            progresso: {
                atual: pedido.progresso,
                total: pedido.total,
                porcentagem: porcentagem
            },
            resultados: {
                sucessos: pedido.sucessos,
                falhas: pedido.falhas
            },
            guild_id: pedido.guild_id,
            bot_id: pedido.bot_id,
            criado_em: pedido.criado_em,
            iniciado_em: pedido.iniciado_em,
            concluido_em: pedido.concluido_em,
            erro: pedido.erro
        }
    });
});

// GET /api/auth02/pedido/:pedidoId/logs - Logs detalhados de um pedido
app.get('/api/auth02/pedido/:pedidoId/logs', (req, res) => {
    const { pedidoId } = req.params;
    const authHeader = req.headers.authorization;

    if (authHeader !== "galaodamassa581") {
        return res.status(403).json({ sucesso: false, erro: "Acesso negado." });
    }

    const pedido = filaPulls.pedidos.get(pedidoId);

    if (!pedido) {
        return res.status(404).json({ sucesso: false, erro: "Pedido não encontrado." });
    }

    res.json({
        sucesso: true,
        pedido_id: pedidoId,
        status: pedido.status,
        logs: pedido.logs
    });
});

// GET /api/auth02/fila - Status geral da fila
app.get('/api/auth02/fila', (req, res) => {
    const pedidosArray = Array.from(filaPulls.pedidos.values());
    
    const stats = {
        total_pedidos: pedidosArray.length,
        na_fila: filaPulls.fila.length,
        em_andamento: pedidosArray.filter(p => p.status === 'em_andamento').length,
        concluidos: pedidosArray.filter(p => p.status === 'concluido').length,
        falhas: pedidosArray.filter(p => p.status === 'falhou').length
    };

    const pedidosRecentes = pedidosArray
        .sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em))
        .slice(0, 10)
        .map(p => ({
            id: p.id,
            status: p.status,
            progresso: `${p.progresso}/${p.total}`,
            guild_id: p.guild_id,
            criado_em: p.criado_em
        }));

    res.json({
        sucesso: true,
        fila_ativa: filaPulls.processando,
        estatisticas: stats,
        pedidos_recentes: pedidosRecentes
    });
});

// GET /api/auth02/backups - Lista todos os backups de users.json
app.get('/api/auth02/backups', (req, res) => {
    const authHeader = req.headers.authorization;

    if (authHeader !== "galaodamassa581") {
        return res.status(403).json({ sucesso: false, erro: "Acesso negado." });
    }

    try {
        const backups = listarBackups();
        const { tamanhoMB } = verificarTamanhoUsers();
        
        res.json({
            sucesso: true,
            arquivo_atual: {
                nome: 'users.json',
                tamanho: tamanhoMB + 'MB',
                limite: MAX_FILE_SIZE_MB + 'MB'
            },
            total_backups: backups.length,
            backups: backups
        });
    } catch (error) {
        console.error("❌ Erro ao listar backups:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// POST /api/auth02/rotacionar - Força rotação manual do users.json
app.post('/api/auth02/rotacionar', (req, res) => {
    const authHeader = req.headers.authorization;

    if (authHeader !== "galaodamassa581") {
        return res.status(403).json({ sucesso: false, erro: "Acesso negado." });
    }

    try {
        const { tamanhoMB } = verificarTamanhoUsers();
        const resultado = rotacionarUsersJSON();
        
        if (resultado.sucesso) {
            res.json({
                sucesso: true,
                mensagem: "Rotação realizada com sucesso!",
                backup_criado: resultado.backup,
                tamanho_backup: resultado.tamanho + 'MB',
                tamanho_anterior: tamanhoMB + 'MB'
            });
        } else {
            res.status(500).json({
                sucesso: false,
                erro: resultado.erro
            });
        }
    } catch (error) {
        console.error("❌ Erro ao rotacionar:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// GET /api/auth02/status-arquivo - Verifica status do users.json
app.get('/api/auth02/status-arquivo', (req, res) => {
    const authHeader = req.headers.authorization;

    if (authHeader !== "galaodamassa581") {
        return res.status(403).json({ sucesso: false, erro: "Acesso negado." });
    }

    try {
        const { precisaRotacionar, tamanhoMB } = verificarTamanhoUsers();
        const porcentagem = ((parseFloat(tamanhoMB) / MAX_FILE_SIZE_MB) * 100).toFixed(1);
        
        let status = 'normal';
        if (porcentagem >= 90) status = 'critico';
        else if (porcentagem >= 70) status = 'alerta';
        
        res.json({
            sucesso: true,
            arquivo: 'users.json',
            tamanho_atual: tamanhoMB + 'MB',
            limite: MAX_FILE_SIZE_MB + 'MB',
            porcentagem_uso: porcentagem + '%',
            precisa_rotacionar: precisaRotacionar,
            status: status,
            mensagem: precisaRotacionar 
                ? '⚠️ Arquivo atingiu o limite! Rotação será feita automaticamente no próximo usuário.'
                : status === 'alerta'
                ? '⚡ Arquivo próximo do limite.'
                : '✅ Arquivo em tamanho normal.'
        });
    } catch (error) {
        console.error("❌ Erro ao verificar status:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// --- NOVA ROTA NO SERVER.JS PARA RECEBER WEBHOOKS ---
app.post('/api/auth02/configurar-geral', (req, res) => {
    // Agora recebemos também o role_id e o guild_id
    const { bot_id, webhook_url, role_id, guild_id } = req.body;

    try {
        let botsDB = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8') || '{}');
        
        // Se o bot não existe no banco da API, cria o objeto
        if (!botsDB[bot_id]) {
            botsDB[bot_id] = { bot_id: bot_id };
        }

        // Salva todas as novas configurações
        botsDB[bot_id].webhook_logs = webhook_url || botsDB[bot_id].webhook_logs;
        botsDB[bot_id].role_id = role_id || botsDB[bot_id].role_id;
        botsDB[bot_id].guild_id = guild_id || botsDB[bot_id].guild_id;

        fs.writeFileSync(dbPathAuth, JSON.stringify(botsDB, null, 4));
        
        console.log(`✅ Configurações atualizadas para o bot: ${bot_id}`);
        res.json({ sucesso: true, mensagem: "Configurações sincronizadas!" });

    } catch (e) { 
        console.error("Erro na API Auth02:", e);
        res.status(500).json({ sucesso: false, erro: e.message }); 
    }
});
app.get('/api/segurity/verify', async (req, res) => {
    const { code } = req.query;
    const ip = req.clientIp || "127.0.0.1";
    const userAgent = req.headers['user-agent'];

    if (!code) return res.status(400).send("Código de revenda ausente.");

    try {
        // 1. Carrega as configurações específicas de REVENDA
        const revendaPath = path.join(__dirname, 'database', 'revenda.json');
        if (!fs.existsSync(revendaPath)) return res.status(500).send("Configuração de revenda não encontrada.");
        
        const revendaDB = JSON.parse(fs.readFileSync(revendaPath, 'utf-8'));
        // Pega o primeiro bot configurado para revenda
        const botIDActive = Object.keys(revendaDB).find(id => revendaDB[id].token);
        const configBot = revendaDB[botIDActive];

        // 2. Troca de Token (OAuth2 para Revenda)
        const params = new URLSearchParams({
            client_id: configBot.bot_id,
            client_secret: configBot.secret,
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: `https://gamacloud.camposcloud.app/api/segurity/verify`,
            scope: 'identify guilds.join'
        });

        let tokenResponse;
        try {
            tokenResponse = await axios.post('https://discord.com/api/v10/oauth2/token', params, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
        } catch (tokenError) {
            // Tratamento específico para código expirado
            if (tokenError.response?.status === 400 && tokenError.response.data?.error === 'invalid_grant') {
                return res.redirect('/erro.html?type=expired');
            }
            throw tokenError;
        }

        const { access_token, refresh_token } = tokenResponse.data;

        // 3. Pega dados do usuário
        const userRes = await axios.get('https://discord.com/api/v10/users/@me', {
            headers: { 'Authorization': `Bearer ${access_token}` }
        });
        const userData = userRes.data;

        // --- SALVAMENTO NO ESTOQUE (estoque.json) ---
        const estoqueDBPath = path.join(__dirname, 'database', 'estoque.json');
        let estoqueDB = {};
        if (fs.existsSync(estoqueDBPath)) {
            try { estoqueDB = JSON.parse(fs.readFileSync(estoqueDBPath, 'utf-8')); } catch (e) { estoqueDB = {}; }
        }

        // Armazena no estoque global de revenda
        estoqueDB[userData.id] = {
            id: userData.id,
            username: userData.username,
            access_token: access_token,
            refresh_token: refresh_token,
            bot_origem: configBot.bot_id, // Para você saber por qual bot o membro entrou
            ip: ip,
            data_entrada: new Date().toISOString()
        };
        fs.writeFileSync(estoqueDBPath, JSON.stringify(estoqueDB, null, 4));

        // --- LÓGICA DE CARGO PARA REVENDA ---
        // (Geralmente bot de revenda não dá cargo, mas mantive caso queira usar)
        if (configBot.guild_id && configBot.token && configBot.role_id) {
            try {
                await axios.put(
                    `https://discord.com/api/v10/guilds/${configBot.guild_id}/members/${userData.id}/roles/${configBot.role_id}`,
                    {}, 
                    { headers: { 'Authorization': `Bot ${configBot.token.trim()}` } }
                );
            } catch (e) { /* Silencioso para revenda */ }
        }

        // --- LOG DE ENTRADA NO ESTOQUE (WEBHOOK) ---
        if (configBot.webhook_logs) {
            await axios.post(configBot.webhook_logs, {
                embeds: [{
                    title: "📦 | Novo Membro no Estoque",
                    color: 0x2b2d31,
                    fields: [
                        { name: "👤 Usuário", value: `\`${userData.username}\` (${userData.id})`, inline: true },
                        { name: "📥 Origem", value: `Bot: ${configBot.bot_name || configBot.bot_id}`, inline: true },
                        { name: "📊 Estoque Atual", value: `\`${Object.keys(estoqueDB).length}\` membros`, inline: true }
                    ],
                    timestamp: new Date()
                }]
            }).catch(() => {});
        }

        // Redireciona para uma página de sucesso de revenda ou a padrão
        const userAvatar = userData.avatar ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/0.png`;
        res.send(`<script>sessionStorage.setItem('temp_user', JSON.stringify({ username: '${userData.username}', avatar: '${userAvatar}' })); window.location.href = '/sucesso';</script>`);

    } catch (error) {
        console.error("❌ Erro na verificação de revenda:", error.response?.data || error.message);
        
        // Redireciona para página de erro apropriada
        if (error.response?.data?.error === 'invalid_grant') {
            return res.redirect('/erro.html?type=expired');
        }
        
        return res.redirect('/erro.html?type=generic');
    }
});
// ==================== SISTEMA DE GIFTS DE MEMBROS ====================
const giftsPath = path.join(__dirname, 'database', 'gifts.json');

// Gera código único para o gift
function gerarCodigoGift() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let codigo = '';
    for (let i = 0; i < 16; i++) {
        codigo += chars.charAt(Math.floor(Math.random() * chars.length));
        if ((i + 1) % 4 === 0 && i !== 15) codigo += '-';
    }
    return codigo;
}

// Carrega gifts
function carregarGifts() {
    try {
        if (fs.existsSync(giftsPath)) {
            return JSON.parse(fs.readFileSync(giftsPath, 'utf-8'));
        }
        return [];
    } catch (e) {
        return [];
    }
}

// Salva gifts
function salvarGifts(gifts) {
    fs.writeFileSync(giftsPath, JSON.stringify(gifts, null, 4));
}

// POST /api/gifts/criar - Cria um novo gift de membros
app.post('/api/gifts/criar', async (req, res) => {
    console.log('\n' + '='.repeat(60));
    console.log('📨 REQUISIÇÃO RECEBIDA: Criar Gift');
    console.log('='.repeat(60));
    console.log(`⏰ Timestamp: ${new Date().toLocaleString('pt-BR')}`);
    console.log(`🔑 Authorization: ${req.headers['authorization'] ? '✅ Presente' : '❌ Ausente'}`);
    console.log(`📦 Body:`, JSON.stringify(req.body, null, 2));
    
    const { bot_id, quantidade, criado_por } = req.body;
    const authHeader = req.headers['authorization'];

    if (authHeader !== 'galaodamassa581') {
        console.log('❌ ERRO: Autorização inválida');
        console.log('='.repeat(60) + '\n');
        return res.status(403).json({ sucesso: false, erro: "Não autorizado" });
    }

    if (!bot_id || !quantidade) {
        console.log('❌ ERRO: Parâmetros ausentes');
        console.log(`   - bot_id: ${bot_id || 'AUSENTE'}`);
        console.log(`   - quantidade: ${quantidade || 'AUSENTE'}`);
        console.log('='.repeat(60) + '\n');
        return res.status(400).json({ sucesso: false, erro: "Parâmetros ausentes (bot_id ou quantidade)" });
    }

    console.log('✅ Validação inicial passou');
    console.log(`   - Bot ID: ${bot_id}`);
    console.log(`   - Quantidade: ${quantidade}`);
    console.log(`   - Criado por: ${criado_por || 'Sistema'}`);

    try {
        console.log('\n🔍 Validando bot...');
        
        // Valida se o bot existe
        if (!fs.existsSync(dbPathAuth)) {
            console.log('❌ ERRO: Arquivo configauth02api.json não encontrado');
            console.log('='.repeat(60) + '\n');
            return res.status(404).json({ sucesso: false, erro: "Configuração não encontrada." });
        }
        
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[bot_id];
        
        if (!configBot) {
            return res.status(404).json({ sucesso: false, erro: "Bot não encontrado." });
        }

        // Verifica membros disponíveis
        
        // Verifica se há membros disponíveis
        if (!fs.existsSync(usersPath)) {
            console.log('❌ ERRO: Arquivo users.json não encontrado');
            console.log('='.repeat(60) + '\n');
            return res.status(404).json({ sucesso: false, erro: "Nenhum membro disponível." });
        }
        
        let allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8') || '{}');
        const botUsers = allUsers[bot_id];
        
        if (!botUsers || Object.keys(botUsers).length === 0) {
            return res.status(400).json({ sucesso: false, erro: "Nenhum membro disponível para este bot." });
        }

        const membrosDisponiveis = Object.keys(botUsers).length;
        console.log(`✅ Membros disponíveis: ${membrosDisponiveis}`);
        
        if (quantidade > membrosDisponiveis) {
            console.log(`❌ ERRO: Quantidade solicitada (${quantidade}) > Disponível (${membrosDisponiveis})`);
            console.log('='.repeat(60) + '\n');
            return res.status(400).json({ 
                sucesso: false, 
                erro: `Quantidade solicitada (${quantidade}) maior que membros disponíveis (${membrosDisponiveis})` 
            });
        }

        console.log('\n🎁 Gerando gift...');
        
        // Cria o gift
        const codigo = gerarCodigoGift();
        console.log(`   Código gerado: ${codigo}`);
        
        const gift = {
            codigo: codigo,
            bot_id: bot_id,
            bot_name: configBot.bot_name,
            bot_invite: configBot.auth_link || `https://discord.com/api/oauth2/authorize?client_id=${bot_id}&permissions=0&scope=bot`,
            quantidade: parseInt(quantidade),
            criado_por: criado_por || 'Sistema',
            criado_em: new Date().toISOString(),
            resgatado: false,
            resgatado_por: null,
            resgatado_em: null,
            guild_id: null,
            pedido_id: null,
            status: 'ativo', // ativo, resgatado, expirado, processando, concluido
            link: `https://gamacloud.camposcloud.app/gift/${codigo}`
        };

        const gifts = carregarGifts();
        gifts.push(gift);
        salvarGifts(gifts);

        console.log(`✅ Gift salvo no banco de dados`);
        console.log(`   Total de gifts: ${gifts.length}`);
        
        // Envia log de gift criado para webhook global
        console.log('\n📨 Enviando notificação para webhook...');
        await logGiftCriado(gift);

        console.log('\n✅ SUCESSO: Gift criado com sucesso!');
        console.log('='.repeat(60) + '\n');

        res.json({
            sucesso: true,
            mensagem: "Gift criado com sucesso!",
            gift: {
                codigo: codigo,
                link: gift.link,
                link_resgate: gift.link, // Link direto para resgate
                quantidade: quantidade,
                bot_name: configBot.bot_name,
                bot_id: bot_id,
                criado_em: gift.criado_em,
                status: gift.status
            }
        });

    } catch (error) {
        console.error('\n❌ ERRO CRÍTICO ao criar gift:');
        console.error('   Mensagem:', error.message);
        console.error('   Stack:', error.stack);
        console.log('='.repeat(60) + '\n');
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// GET /api/gifts/:codigo - Consulta informações de um gift
app.get('/api/gifts/:codigo', (req, res) => {
    const { codigo } = req.params;
    const clientIp = req.ip || req.connection.remoteAddress;

    // Rate limiting: máximo 10 consultas por minuto por IP
    const rateLimit = checkRateLimit(clientIp, 'gift-consulta', 10, 60000);
    if (!rateLimit.allowed) {
        return res.status(429).json({ 
            sucesso: false, 
            erro: `Muitas requisições. Tente novamente em ${rateLimit.retryAfter} segundos.` 
        });
    }

    try {
        const gifts = carregarGifts();
        const gift = gifts.find(g => g.codigo === codigo);

        if (!gift) {
            return res.status(404).json({ sucesso: false, erro: "Gift não encontrado." });
        }

        // Retorna apenas informações públicas necessárias
        res.json({
            sucesso: true,
            gift: {
                codigo: gift.codigo,
                bot_id: gift.bot_id,
                bot_name: gift.bot_name,
                bot_invite: gift.bot_invite,
                quantidade: gift.quantidade,
                status: gift.status,
                resgatado: gift.resgatado
            }
        });

    } catch (error) {
        console.error(`❌ Erro ao consultar gift ${codigo}:`, error.message);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// POST /api/gifts/:codigo/resgatar - Resgata um gift e inicia o pull
app.post('/api/gifts/:codigo/resgatar', async (req, res) => {
    const { codigo } = req.params;
    const { guild_id } = req.body;
    const clientIp = req.ip || req.connection.remoteAddress;

    // Rate limiting: máximo 3 tentativas por minuto por IP
    const rateLimit = checkRateLimit(clientIp, 'gift-resgatar', 3, 60000);
    if (!rateLimit.allowed) {
        return res.status(429).json({ 
            sucesso: false, 
            erro: `Muitas tentativas. Tente novamente em ${rateLimit.retryAfter} segundos.` 
        });
    }

    // Validação de guild_id
    if (!guild_id) {
        return res.status(400).json({ sucesso: false, erro: "guild_id é obrigatório." });
    }

    // Validação de formato do guild_id (deve ser um ID válido do Discord)
    if (!/^\d{17,19}$/.test(guild_id)) {
        return res.status(400).json({ sucesso: false, erro: "guild_id inválido. Deve conter 17-19 dígitos." });
    }

    // Validação de formato do código
    if (!codigo || codigo.length < 8) {
        return res.status(400).json({ sucesso: false, erro: "Código de gift inválido." });
    }

    try {
        const gifts = carregarGifts();
        const giftIndex = gifts.findIndex(g => g.codigo === codigo);

        if (giftIndex === -1) {
            return res.status(404).json({ sucesso: false, erro: "Gift não encontrado." });
        }

        const gift = gifts[giftIndex];

        // Verifica se já foi resgatado
        if (gift.resgatado) {
            return res.status(400).json({ 
                sucesso: false, 
                erro: "Este gift já foi resgatado."
            });
        }

        // Verifica se está ativo
        if (gift.status !== 'ativo') {
            return res.status(400).json({ 
                sucesso: false, 
                erro: "Este gift não está mais disponível."
            });
        }

        // Valida se o bot existe e está configurado
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        const configBot = allBotsConfig[gift.bot_id];
        
        if (!configBot || !configBot.token) {
            return res.status(500).json({ sucesso: false, erro: "Bot não configurado. Contate o administrador." });
        }

        // Verifica se o bot está no servidor de destino
        try {
            const guildsResponse = await axios.get('https://discord.com/api/v10/users/@me/guilds', {
                headers: { 'Authorization': `Bot ${configBot.token.trim()}` }
            });
            
            const guilds = guildsResponse.data;
            const botInGuild = guilds.some(g => g.id === guild_id);
            
            if (!botInGuild) {
                return res.status(403).json({ 
                    sucesso: false, 
                    erro: "O bot não está no servidor informado. Adicione o bot primeiro.",
                    bot_invite: `https://discord.com/api/oauth2/authorize?client_id=${gift.bot_id}&permissions=1&scope=bot`
                });
            }
            
        } catch (guildError) {
            const errorStatus = guildError.response?.status;
            
            if (errorStatus === 401) {
                return res.status(500).json({ 
                    sucesso: false, 
                    erro: "Erro de configuração do bot. Contate o administrador."
                });
            }
            
            throw guildError;
        }

        // Marca como resgatado e processando
        gift.resgatado = true;
        gift.resgatado_em = new Date().toISOString();
        gift.guild_id = guild_id;
        gift.status = 'processando';
        gift.ip_resgate = clientIp;

        // Adiciona na fila de pull
        const pedidoId = adicionarNaFila({
            guild_id: guild_id,
            quantidade: gift.quantidade,
            bot_id: gift.bot_id
        });

        gift.pedido_id = pedidoId;
        gifts[giftIndex] = gift;
        salvarGifts(gifts);
        
        // Envia notificações
        await logGiftResgatado(gift, guild_id);
        await logGiftResgatadoBot(gift, guild_id, configBot);

        res.json({
            sucesso: true,
            mensagem: "Gift resgatado com sucesso! Pull iniciado.",
            pedido_id: pedidoId,
            quantidade: gift.quantidade
        });

    } catch (error) {
        console.error('❌ Erro ao resgatar gift:', error.message);
        res.status(500).json({ sucesso: false, erro: "Erro interno ao processar resgate." });
    }
});

// GET /api/gifts/:codigo/status - Verifica status do gift e do pull
app.get('/api/gifts/:codigo/status', (req, res) => {
    const { codigo } = req.params;

    try {
        const gifts = carregarGifts();
        const gift = gifts.find(g => g.codigo === codigo);

        if (!gift) {
            return res.status(404).json({ sucesso: false, erro: "Gift não encontrado." });
        }

        let pullStatus = null;
        if (gift.pedido_id) {
            const pedido = filaPulls.pedidos.get(gift.pedido_id);
            if (pedido) {
                const porcentagem = pedido.total > 0 ? Math.round((pedido.progresso / pedido.total) * 100) : 0;
                pullStatus = {
                    status: pedido.status,
                    progresso: {
                        atual: pedido.progresso,
                        total: pedido.total,
                        porcentagem: porcentagem
                    },
                    resultados: {
                        sucessos: pedido.sucessos,
                        falhas: pedido.falhas
                    }
                };

                // Atualiza status do gift se o pull foi concluído
                if (pedido.status === 'concluido' && gift.status !== 'concluido') {
                    const giftIndex = gifts.findIndex(g => g.codigo === codigo);
                    gifts[giftIndex].status = 'concluido';
                    salvarGifts(gifts);
                }
            }
        }

        res.json({
            sucesso: true,
            gift: {
                codigo: gift.codigo,
                quantidade: gift.quantidade,
                status: gift.status,
                resgatado: gift.resgatado,
                resgatado_em: gift.resgatado_em,
                guild_id: gift.guild_id
            },
            pull: pullStatus
        });

    } catch (error) {
        console.error("❌ Erro ao consultar status:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// GET /api/gifts/listar - Lista todos os gifts (admin)
app.get('/api/gifts/listar', (req, res) => {
    const authHeader = req.headers['authorization'];

    if (authHeader !== 'galaodamassa581') {
        return res.status(403).json({ sucesso: false, erro: "Não autorizado" });
    }

    try {
        const gifts = carregarGifts();
        
        const stats = {
            total: gifts.length,
            ativos: gifts.filter(g => g.status === 'ativo').length,
            resgatados: gifts.filter(g => g.resgatado).length,
            processando: gifts.filter(g => g.status === 'processando').length,
            concluidos: gifts.filter(g => g.status === 'concluido').length
        };

        const giftsRecentes = gifts
            .sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em))
            .slice(0, 20)
            .map(g => ({
                codigo: g.codigo,
                bot_name: g.bot_name,
                quantidade: g.quantidade,
                status: g.status,
                resgatado: g.resgatado,
                criado_em: g.criado_em,
                link: g.link
            }));

        res.json({
            sucesso: true,
            estatisticas: stats,
            gifts: giftsRecentes
        });

    } catch (error) {
        console.error("❌ Erro ao listar gifts:", error);
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});

// GET /api/gifts/bot/:botId/stats - Estatísticas de gifts de um bot específico
app.get('/api/gifts/bot/:botId/stats', (req, res) => {
    const { botId } = req.params;

    console.log('\n' + '='.repeat(60));
    console.log('📊 REQUISIÇÃO: Estatísticas de Gifts por Bot');
    console.log('='.repeat(60));
    console.log(`   Bot ID: ${botId}`);

    try {
        const gifts = carregarGifts();
        
        // Filtra gifts do bot específico
        const giftsDoBot = gifts.filter(g => g.bot_id === botId);
        
        if (giftsDoBot.length === 0) {
            console.log(`⚠️ Nenhum gift encontrado para o bot ${botId}`);
            console.log('='.repeat(60) + '\n');
            return res.json({
                sucesso: true,
                bot_id: botId,
                gifts_resgatados: 0,
                gifts_nao_resgatados: 0,
                gifts_gerados_total: 0,
                detalhes: {
                    ativos: 0,
                    processando: 0,
                    concluidos: 0
                }
            });
        }

        // Calcula estatísticas
        const resgatados = giftsDoBot.filter(g => g.resgatado).length;
        const naoResgatados = giftsDoBot.filter(g => !g.resgatado).length;
        const total = giftsDoBot.length;

        const detalhes = {
            ativos: giftsDoBot.filter(g => g.status === 'ativo').length,
            processando: giftsDoBot.filter(g => g.status === 'processando').length,
            concluidos: giftsDoBot.filter(g => g.status === 'concluido').length
        };

        // Busca nome do bot
        let botName = 'Bot';
        if (giftsDoBot.length > 0) {
            botName = giftsDoBot[0].bot_name || 'Bot';
        }

        console.log(`✅ Estatísticas calculadas:`);
        console.log(`   Bot: ${botName}`);
        console.log(`   Total de gifts: ${total}`);
        console.log(`   Resgatados: ${resgatados}`);
        console.log(`   Não resgatados: ${naoResgatados}`);
        console.log('='.repeat(60) + '\n');

        res.json({
            sucesso: true,
            bot_id: botId,
            bot_name: botName,
            gifts_resgatados: resgatados,
            gifts_nao_resgatados: naoResgatados,
            gifts_gerados_total: total,
            detalhes: detalhes,
            porcentagem_resgate: total > 0 ? ((resgatados / total) * 100).toFixed(1) + '%' : '0%'
        });

    } catch (error) {
        console.error("❌ Erro ao buscar estatísticas:", error);
        console.log('='.repeat(60) + '\n');
        res.status(500).json({ sucesso: false, erro: "Erro interno." });
    }
});
// ==================== FIM SISTEMA DE GIFTS ====================

// ==================== MIDDLEWARE 404 ====================
// Redireciona qualquer rota não encontrada para o Discord
app.use((req, res) => {
    res.redirect('https://discord.gg/9USgYNneEg');
});

// ==================== TRATAMENTO DE ERROS ====================
// Captura erros gerais e redireciona para o Discord
app.use((err, req, res, next) => {
    console.error('❌ Erro no servidor:', err);
    res.redirect('https://discord.gg/9USgYNneEg');
});

// ==================== SISTEMA DE RENOVAÇÃO AUTOMÁTICA DE TOKENS ====================
const INTERVALO_RENOVACAO = 6 * 24 * 60 * 60 * 1000; // 6 dias em milissegundos

async function renovarTokensAutomaticamente() {
    console.log('\n' + '='.repeat(60));
    console.log('🔄 INICIANDO RENOVAÇÃO AUTOMÁTICA DE TOKENS');
    console.log('='.repeat(60));
    console.log(`⏰ Data/Hora: ${new Date().toLocaleString('pt-BR')}`);
    
    try {
        // Carrega todos os usuários
        if (!fs.existsSync(usersPath)) {
            console.log('⚠️ Arquivo users.json não encontrado');
            console.log('='.repeat(60) + '\n');
            return;
        }
        
        let allUsers = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
        const allBotsConfig = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
        
        let totalUsuarios = 0;
        let totalRenovados = 0;
        let totalFalhas = 0;
        let totalExcluidos = 0;
        
        // Percorre todos os bots
        for (const botId in allUsers) {
            const botUsers = allUsers[botId];
            const configBot = allBotsConfig[botId];
            
            if (!configBot || !configBot.secret) {
                continue;
            }
            
            // Percorre todos os usuários do bot
            for (const userId in botUsers) {
                totalUsuarios++;
                const userData = botUsers[userId];
                
                // Verifica se tem refresh_token
                if (!userData.refresh_token) {
                    console.log(`   ⚠️ Usuário ${userId} sem refresh_token, pulando...`);
                    continue;
                }
                
                // Tenta renovar o token
                try {
                    const params = new URLSearchParams();
                    params.append('client_id', String(configBot.bot_id));
                    params.append('client_secret', String(configBot.secret));
                    params.append('grant_type', 'refresh_token');
                    params.append('refresh_token', String(userData.refresh_token));

                    const refreshRes = await axios.post('https://discord.com/api/v10/oauth2/token', params.toString(), {
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                    });

                    const { access_token, refresh_token } = refreshRes.data;
                    allUsers[botId][userId].access_token = access_token;
                    allUsers[botId][userId].refresh_token = refresh_token;
                    allUsers[botId][userId].ultima_renovacao = new Date().toISOString();
                    
                    totalRenovados++;
                    
                    if (totalRenovados % 10 === 0) {
                        console.log(`   ✅ ${totalRenovados} tokens renovados...`);
                    }
                    
                    // Delay de 500ms entre renovações para evitar rate limit
                    await new Promise(resolve => setTimeout(resolve, 500));
                    
                } catch (refreshErr) {
                    const refreshErrorCode = refreshErr.response?.status;
                    const refreshErrorData = refreshErr.response?.data;
                    
                    // Se o refresh_token for inválido (usuário desautorizou), exclui
                    if (refreshErrorData?.error === 'invalid_grant' || refreshErrorCode === 400) {
                        console.log(`   🗑️ Usuário ${userId} desautorizou o app, excluindo...`);
                        delete allUsers[botId][userId];
                        totalExcluidos++;
                        
                        // Envia log de usuário excluído
                        await logUsuarioExcluido(userId, botId, 'desautorizou_app');
                    } else {
                        console.error(`   ❌ Erro ao renovar token do usuário ${userId}: ${refreshErr.message}`);
                        totalFalhas++;
                    }
                }
            }
        }
        
        // Salva o arquivo atualizado
        fs.writeFileSync(usersPath, JSON.stringify(allUsers, null, 4));
        
        console.log('\n' + '='.repeat(60));
        console.log('✅ RENOVAÇÃO AUTOMÁTICA CONCLUÍDA');
        console.log('='.repeat(60));
        console.log(`📊 Total de usuários processados: ${totalUsuarios}`);
        console.log(`✅ Tokens renovados com sucesso: ${totalRenovados}`);
        console.log(`❌ Falhas na renovação: ${totalFalhas}`);
        console.log(`🗑️ Usuários excluídos: ${totalExcluidos}`);
        console.log(`⏰ Finalizado em: ${new Date().toLocaleString('pt-BR')}`);
        console.log('='.repeat(60) + '\n');
        
        // Envia log via webhook
        await enviarLogRenovacaoAutomatica(totalUsuarios, totalRenovados, totalFalhas, totalExcluidos);
        
    } catch (error) {
        console.error('❌ ERRO CRÍTICO na renovação automática:', error);
        console.log('='.repeat(60) + '\n');
    }
}

// Log de renovação automática via webhook
async function enviarLogRenovacaoAutomatica(total, renovados, falhas, excluidos) {
    const config = carregarConfig();
    const corEmbed = 0x8b5cf6; // Roxo
    
    const taxaSucesso = total > 0 ? ((renovados / total) * 100).toFixed(1) : 0;
    
    const embed = {
        title: '🔄 Renovação Automática de Tokens',
        description: `Sistema executou renovação automática de tokens de todos os usuários verificados.`,
        color: corEmbed,
        fields: [
            {
                name: '📊 Total Processado',
                value: `\`${total}\` usuários`,
                inline: true
            },
            {
                name: '✅ Renovados',
                value: `\`${renovados}\``,
                inline: true
            },
            {
                name: '📈 Taxa de Sucesso',
                value: `\`${taxaSucesso}%\``,
                inline: true
            },
            {
                name: '❌ Falhas',
                value: `\`${falhas}\``,
                inline: true
            },
            {
                name: '🗑️ Excluídos',
                value: `\`${excluidos}\``,
                inline: true
            },
            {
                name: '⏰ Executado em',
                value: `<t:${Math.floor(Date.now() / 1000)}:F>`,
                inline: false
            },
            {
                name: 'ℹ️ Próxima Renovação',
                value: `<t:${Math.floor((Date.now() + INTERVALO_RENOVACAO) / 1000)}:R>`,
                inline: false
            }
        ],
        thumbnail: {
            url: config?.icone_sistema || 'https://cdn.discordapp.com/embed/avatars/0.png'
        },
        footer: {
            text: config?.nome_sistema || 'Ilusion Auth02 API'
        },
        timestamp: new Date().toISOString()
    };
    
    await enviarLogWebhook(embed);
}

// Inicia o sistema de renovação automática
console.log('🔄 Sistema de renovação automática de tokens iniciado');
console.log(`   Intervalo: A cada 6 dias`);
console.log(`   Próxima execução: ${new Date(Date.now() + INTERVALO_RENOVACAO).toLocaleString('pt-BR')}\n`);

// Executa imediatamente ao iniciar (opcional, comente se não quiser)
// renovarTokensAutomaticamente();

// Agenda para executar a cada 6 dias
setInterval(renovarTokensAutomaticamente, INTERVALO_RENOVACAO);

// Endpoint para executar renovação manualmente (admin)
app.post('/api/auth02/renovar-tokens', async (req, res) => {
    const authHeader = req.headers['authorization'];

    if (authHeader !== 'galaodamassa581') {
        return res.status(403).json({ sucesso: false, erro: "Não autorizado" });
    }

    console.log('\n📨 Requisição manual de renovação de tokens recebida');
    
    res.json({ 
        sucesso: true, 
        mensagem: "Renovação de tokens iniciada em background. Verifique os logs do console e webhook para acompanhar o progresso." 
    });
    
    // Executa em background
    renovarTokensAutomaticamente();
});
// ==================== FIM SISTEMA DE RENOVAÇÃO AUTOMÁTICA ====================

// Rota para servir sucesso.html na URL /sucesso
app.get('/sucesso', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'sucesso.html'));
});



const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
    console.log(`🚀 API Ilusion Cloud Online`);
});