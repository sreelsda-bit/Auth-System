# Pasta de Produtos

Esta pasta contém os templates de aplicações que serão deployadas na SquareCloud.

## bot-template.zip

Este arquivo deve conter:
- `config.json` - Arquivo de configuração com campos `token` e `owner`
- Demais arquivos do bot/aplicação

### Estrutura do config.json

```json
{
  "token": "",
  "owner": "",
  "outros_campos": "valores"
}
```

Os campos `token` e `owner` serão preenchidos automaticamente pelo sistema de deploy.

## Como Adicionar um Novo Template

1. Crie um ZIP com todos os arquivos da aplicação
2. Certifique-se de que há um `config.json` na raiz do ZIP
3. Coloque o ZIP nesta pasta
4. Atualize o código em `deploy.js` se necessário
