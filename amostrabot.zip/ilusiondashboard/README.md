# Illusion Dashboard - SquareCloud Deploy

Sistema de deploy automático para SquareCloud através da API.

## Estrutura

```
ilusiondashboard/
├── produtos/
│   └── bot-template.zip    # Template do bot (ZIP com config.json)
├── deploy.js               # Lógica de deploy
├── routes.js               # Rotas da API
└── README.md              # Documentação
```

## Como Funciona

1. O site envia uma requisição POST com `square_token`, `owner` e `bot_token`
2. O sistema busca o nome do bot usando o token do Discord
3. Extrai o ZIP do template
4. Edita o `config.json` com `token` e `owner`
5. Edita o `squarecloud.app` com nome do bot, RAM 256 e main index.js
6. Cria um novo ZIP
7. Envia para a SquareCloud via API
8. Retorna o `appid`, status e nome do bot

## Endpoint

### POST /ilusiondashboard/deploy

**Body:**
```json
{
  "square_token": "seu_token_squarecloud",
  "owner": "id_do_owner",
  "bot_token": "token_do_bot_discord"
}
```

**Resposta de Sucesso:**
```json
{
  "appid": "app_id_gerado",
  "status": "sucesso",
  "message": "Deploy realizado com sucesso",
  "bot_name": "Nome do Bot"
}
```

**Resposta de Erro:**
```json
{
  "status": "erro",
  "message": "Descrição do erro",
  "detalhes": {}
}
```

## Instalação

As dependências serão instaladas automaticamente:
- `adm-zip`: Para manipular arquivos ZIP
- `@squarecloud/api`: SDK oficial da SquareCloud
- `form-data`: Para envio de arquivos multipart

Execute:
```bash
npm install
```

## Uso no Server.js

Adicione no seu `server.js`:

```javascript
const illusionDashboard = require('./ilusiondashboard/routes');
app.use('/ilusiondashboard', illusionDashboard);
```
