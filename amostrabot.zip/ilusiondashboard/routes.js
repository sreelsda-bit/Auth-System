const express = require('express');
const router = express.Router();
const { deployToSquareCloud } = require('./deploy');

/**
 * POST /ilusiondashboard/deploy
 * Body: { square_token: string, owner: string, bot_token: string }
 * Retorna: { appid: string, status: string, bot_name: string }
 */
router.post('/deploy', async (req, res) => {
    try {
        const { square_token, owner, bot_token } = req.body;
        
        // Validações
        if (!square_token || !owner || !bot_token) {
            return res.status(400).json({
                status: 'erro',
                message: 'square_token, owner e bot_token são obrigatórios'
            });
        }
        
        if (typeof square_token !== 'string' || typeof owner !== 'string' || typeof bot_token !== 'string') {
            return res.status(400).json({
                status: 'erro',
                message: 'Todos os campos devem ser strings'
            });
        }
        
        // Realiza o deploy
        const resultado = await deployToSquareCloud(square_token, owner, bot_token);
        
        res.json({
            appid: resultado.appid,
            status: resultado.status,
            message: resultado.message,
            bot_name: resultado.bot_name
        });
        
    } catch (error) {
        console.error('Erro na rota de deploy:', error);
        
        res.status(500).json({
            status: 'erro',
            message: error.message || 'Erro ao realizar deploy',
            detalhes: error.response?.data || null
        });
    }
});

/**
 * GET /ilusiondashboard/status
 * Verifica se o serviço está funcionando
 */
router.get('/status', (req, res) => {
    res.json({
        status: 'online',
        servico: 'Illusion Dashboard - SquareCloud Deploy',
        versao: '1.0.0'
    });
});

module.exports = router;
