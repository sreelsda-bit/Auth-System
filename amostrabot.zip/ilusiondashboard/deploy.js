const AdmZip = require('adm-zip');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

/**
 * Busca o nome do bot usando o token
 * @param {string} botToken - Token do bot do Discord
 * @returns {Promise<string>}
 */
async function getBotName(botToken) {
    try {
        const response = await axios.get('https://discord.com/api/v10/users/@me', {
            headers: { 'Authorization': `Bot ${botToken.trim()}` }
        });
        return response.data.username || 'Bot';
    } catch (error) {
        console.error('Erro ao buscar nome do bot:', error.message);
        return 'Bot';
    }
}

/**
 * Deploy de aplicação na SquareCloud
 * @param {string} squareToken - Token da SquareCloud
 * @param {string} ownerId - ID do owner
 * @param {string} botToken - Token do bot do Discord
 * @returns {Promise<{appid: string, status: string}>}
 */
async function deployToSquareCloud(squareToken, ownerId, botToken) {
    try {
        const zipPath = path.join(__dirname, 'produtos', 'bot-template.zip');
        const tempZipPath = path.join(__dirname, 'produtos', 'temp-deploy.zip');
        
        // 1. Busca o nome do bot
        const botName = await getBotName(botToken);
        
        // 2. Extrai o ZIP original
        const zip = new AdmZip(zipPath);
        const tempDir = path.join(__dirname, 'produtos', 'temp-extract');
        
        // Remove diretório temporário se existir
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true, force: true });
        }
        
        zip.extractAllTo(tempDir, true);
        
        // 3. Edita o config.json
        const configPath = path.join(tempDir, 'config.json');
        
        if (!fs.existsSync(configPath)) {
            throw new Error('config.json não encontrado no ZIP');
        }
        
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        config.token = botToken;
        config.owner = ownerId;
        
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
        
        // 4. Edita o squarecloud.app ou squarecloud.config
        let squareConfigPath = path.join(tempDir, 'squarecloud.app');
        if (!fs.existsSync(squareConfigPath)) {
            squareConfigPath = path.join(tempDir, 'squarecloud.config');
        }
        
        if (!fs.existsSync(squareConfigPath)) {
            // Cria o arquivo se não existir
            squareConfigPath = path.join(tempDir, 'squarecloud.app');
        }
        
        const squareConfig = `DISPLAY_NAME=${botName}
MAIN=index.js
MEMORY=256
VERSION=recommended`;
        
        fs.writeFileSync(squareConfigPath, squareConfig);
        
        // 5. Cria novo ZIP com as alterações
        const newZip = new AdmZip();
        
        function addFolderToZip(folderPath, zipPath = '') {
            const items = fs.readdirSync(folderPath);
            
            for (const item of items) {
                const itemPath = path.join(folderPath, item);
                const stat = fs.statSync(itemPath);
                
                if (stat.isDirectory()) {
                    addFolderToZip(itemPath, path.join(zipPath, item));
                } else {
                    const content = fs.readFileSync(itemPath);
                    newZip.addFile(path.join(zipPath, item), content);
                }
            }
        }
        
        addFolderToZip(tempDir);
        newZip.writeZip(tempZipPath);
        
        // 6. Envia para SquareCloud usando a API oficial
        const FormData = require('form-data');
        const form = new FormData();
        
        form.append('file', fs.createReadStream(tempZipPath));
        
        const response = await axios.post('https://api.squarecloud.app/v2/upload', form, {
            headers: {
                ...form.getHeaders(),
                'Authorization': squareToken
            }
        });
        
        // 7. Limpa arquivos temporários
        fs.rmSync(tempDir, { recursive: true, force: true });
        fs.unlinkSync(tempZipPath);
        
        // 8. Retorna resultado
        if (response.data && response.data.response) {
            return {
                appid: response.data.response.id || response.data.response.app_id,
                status: 'sucesso',
                message: 'Deploy realizado com sucesso',
                bot_name: botName
            };
        }
        
        throw new Error('Resposta inválida da SquareCloud');
        
    } catch (error) {
        console.error('Erro no deploy:', error.message);
        throw error;
    }
}

module.exports = { deployToSquareCloud };
