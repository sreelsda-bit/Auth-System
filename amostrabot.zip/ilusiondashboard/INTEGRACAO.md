# Guia de Integração - Illusion Dashboard API

Este documento explica como integrar seu site com a API de deploy da SquareCloud.

## 📋 Informações Básicas

**Endpoint Base:** `https://gamacloud.camposcloud.app/ilusiondashboard`

**Método:** `POST`

**Content-Type:** `application/json`

---

## 🚀 Como Enviar os Dados

### Endpoint de Deploy

```
POST /ilusiondashboard/deploy
```

### Parâmetros Necessários

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `square_token` | string | ✅ Sim | Token de autenticação da SquareCloud |
| `owner` | string | ✅ Sim | ID do Discord do proprietário |
| `bot_token` | string | ✅ Sim | Token do bot do Discord |

### Exemplo de Requisição

#### JavaScript (Fetch API)

```javascript
async function deployBot(squareToken, ownerId, botToken) {
    try {
        const response = await fetch('https://gamacloud.camposcloud.app/ilusiondashboard/deploy', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                square_token: squareToken,
                owner: ownerId,
                bot_token: botToken
            })
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log('Deploy realizado com sucesso!');
            console.log('App ID:', data.appid);
            console.log('Nome do Bot:', data.bot_name);
            return data;
        } else {
            console.error('Erro no deploy:', data.message);
            throw new Error(data.message);
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        throw error;
    }
}

// Uso
deployBot('SEU_TOKEN_SQUARE', '123456789012345678', 'SEU_TOKEN_BOT')
    .then(resultado => {
        alert(`Bot deployado! App ID: ${resultado.appid}`);
    })
    .catch(erro => {
        alert(`Erro: ${erro.message}`);
    });
```

#### JavaScript (Axios)

```javascript
const axios = require('axios');

async function deployBot(squareToken, ownerId, botToken) {
    try {
        const response = await axios.post('https://gamacloud.camposcloud.app/ilusiondashboard/deploy', {
            square_token: squareToken,
            owner: ownerId,
            bot_token: botToken
        });

        console.log('Deploy realizado com sucesso!');
        console.log('App ID:', response.data.appid);
        console.log('Nome do Bot:', response.data.bot_name);
        
        return response.data;
    } catch (error) {
        console.error('Erro no deploy:', error.response?.data || error.message);
        throw error;
    }
}
```

#### cURL

```bash
curl -X POST https://gamacloud.camposcloud.app/ilusiondashboard/deploy \
  -H "Content-Type: application/json" \
  -d '{
    "square_token": "SEU_TOKEN_SQUARE",
    "owner": "123456789012345678",
    "bot_token": "SEU_TOKEN_BOT"
  }'
```

---

## 📥 Como Receber o App ID

### Resposta de Sucesso (Status 200)

```json
{
  "appid": "abc123def456",
  "status": "sucesso",
  "message": "Deploy realizado com sucesso",
  "bot_name": "Meu Bot Incrível"
}
```

### Campos da Resposta

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `appid` | string | ID da aplicação na SquareCloud (use para gerenciar o app) |
| `status` | string | Status do deploy ("sucesso" ou "erro") |
| `message` | string | Mensagem descritiva do resultado |
| `bot_name` | string | Nome do bot obtido automaticamente |

### Resposta de Erro (Status 4xx/5xx)

```json
{
  "status": "erro",
  "message": "Descrição do erro",
  "detalhes": {
    "campo": "informação adicional"
  }
}
```

---

## 💡 Exemplo Completo de Integração

### HTML + JavaScript

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Deploy Bot - Illusion Dashboard</title>
</head>
<body>
    <h1>Deploy de Bot na SquareCloud</h1>
    
    <form id="deployForm">
        <label>Token SquareCloud:</label>
        <input type="text" id="squareToken" required>
        <br><br>
        
        <label>ID do Owner (Discord):</label>
        <input type="text" id="ownerId" required>
        <br><br>
        
        <label>Token do Bot (Discord):</label>
        <input type="password" id="botToken" required>
        <br><br>
        
        <button type="submit">Fazer Deploy</button>
    </form>
    
    <div id="resultado"></div>

    <script>
        document.getElementById('deployForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const squareToken = document.getElementById('squareToken').value;
            const ownerId = document.getElementById('ownerId').value;
            const botToken = document.getElementById('botToken').value;
            const resultadoDiv = document.getElementById('resultado');
            
            resultadoDiv.innerHTML = '<p>⏳ Fazendo deploy...</p>';
            
            try {
                const response = await fetch('https://gamacloud.camposcloud.app/ilusiondashboard/deploy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        square_token: squareToken,
                        owner: ownerId,
                        bot_token: botToken
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    resultadoDiv.innerHTML = `
                        <h2>✅ Deploy Realizado com Sucesso!</h2>
                        <p><strong>App ID:</strong> ${data.appid}</p>
                        <p><strong>Nome do Bot:</strong> ${data.bot_name}</p>
                        <p><strong>Status:</strong> ${data.status}</p>
                        <p><a href="https://squarecloud.app/dashboard/app/${data.appid}" target="_blank">
                            Ver na SquareCloud
                        </a></p>
                    `;
                } else {
                    resultadoDiv.innerHTML = `
                        <h2>❌ Erro no Deploy</h2>
                        <p>${data.message}</p>
                    `;
                }
            } catch (error) {
                resultadoDiv.innerHTML = `
                    <h2>❌ Erro na Requisição</h2>
                    <p>${error.message}</p>
                `;
            }
        });
    </script>
</body>
</html>
```

---

## 🔍 Verificar Status do Serviço

Para verificar se a API está online:

```
GET /ilusiondashboard/status
```

**Resposta:**
```json
{
  "status": "online",
  "servico": "Illusion Dashboard - SquareCloud Deploy",
  "versao": "1.0.0"
}
```

---

## ⚠️ Tratamento de Erros

### Erros Comuns

| Status | Erro | Solução |
|--------|------|---------|
| 400 | Parâmetros ausentes | Verifique se enviou todos os campos obrigatórios |
| 400 | Campos devem ser strings | Certifique-se de enviar strings, não números |
| 401 | Token inválido | Verifique se o token da SquareCloud está correto |
| 403 | Sem permissão | Verifique as permissões do token |
| 500 | Erro interno | Verifique os logs do servidor ou tente novamente |

### Exemplo de Tratamento

```javascript
async function deployComTratamento(squareToken, ownerId, botToken) {
    try {
        const response = await fetch('https://gamacloud.camposcloud.app/ilusiondashboard/deploy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                square_token: squareToken,
                owner: ownerId,
                bot_token: botToken
            })
        });

        const data = await response.json();

        if (!response.ok) {
            // Tratamento específico por status
            switch (response.status) {
                case 400:
                    throw new Error(`Dados inválidos: ${data.message}`);
                case 401:
                    throw new Error('Token da SquareCloud inválido');
                case 403:
                    throw new Error('Sem permissão para fazer deploy');
                case 500:
                    throw new Error('Erro no servidor. Tente novamente mais tarde');
                default:
                    throw new Error(data.message || 'Erro desconhecido');
            }
        }

        return data;
    } catch (error) {
        console.error('Erro no deploy:', error);
        throw error;
    }
}
```

---

## 📝 Notas Importantes

1. **Segurança**: Nunca exponha tokens no frontend. Faça a requisição através do seu backend.

2. **Rate Limiting**: A API da SquareCloud pode ter limites de requisições. Implemente delays entre deploys.

3. **Validação**: Valide os dados no frontend antes de enviar para evitar erros desnecessários.

4. **Logs**: Salve o `appid` retornado para gerenciar a aplicação posteriormente.

5. **Timeout**: Deploys podem demorar. Configure um timeout adequado (recomendado: 60 segundos).

---

## 🎯 Fluxo Completo

```
1. Usuário preenche formulário no site
   ↓
2. Site envia POST para /ilusiondashboard/deploy
   ↓
3. API busca nome do bot usando bot_token
   ↓
4. API edita config.json e squarecloud.app
   ↓
5. API cria novo ZIP e envia para SquareCloud
   ↓
6. SquareCloud processa e retorna App ID
   ↓
7. API retorna App ID para o site
   ↓
8. Site exibe sucesso e App ID para o usuário
```

---

## 📞 Suporte

Se encontrar problemas, verifique:
- Logs do servidor
- Validade dos tokens
- Formato do ZIP template
- Conexão com a API da SquareCloud

---

**Desenvolvido por Illusion Solutions** 🚀
