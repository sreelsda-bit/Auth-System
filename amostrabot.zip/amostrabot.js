const { 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, 
    ModalBuilder, TextInputBuilder, TextInputStyle, 
    InteractionType 
} = require("discord.js");
const axios = require("axios");
const fs = require('fs');
const path = require('path');
const { Emojis } = require("../../DataBaseJson/index");
const { res } = require("../../res");

const API_URL = "https://ilusionsoluctions.camposcloud.app";
const AUTH_TOKEN = "galaodamassa581";
const dbPathAuth = path.join(__dirname, "..", "..", "DataBaseJson", "configauth02api.json");
const giftsPath = path.join(__dirname, "..", "..", "DataBaseJson", "gifts.json");

module.exports = {
    name: 'interactionCreate',

    async run(interaction, client) {

        // --- 1. BOTÃO: GERENCIAR GIFTS MEMBROS ---
        if (interaction.isButton() && interaction.customId === 'gerenciar_gifts_membros') {
            const { PainelGifts } = require('../../Functions/GerenciarGifts.js');
            return PainelGifts(interaction);
        }

        // --- 2. BOTÃO: VOLTAR PARA O PAINEL AUTH02 ---
        if (interaction.isButton() && interaction.customId === 'voltar_painel_auth02') {
            const { auth02api } = require('../../Functions/configurarauth02.js');
            return auth02api(interaction);
        }

        // --- 3. BOTÃO: CRIAR GIFT MEMBRO (ABRE MODAL) ---
        if (interaction.isButton() && interaction.customId === 'criar_gift_membro') {
            // Verificar se o bot auth está configurado
            if (!fs.existsSync(dbPathAuth)) {
                return interaction.reply({
                    content: `${Emojis.get('negative')} Configure o Bot Auth02 primeiro!`,
                    ephemeral: true
                });
            }

            const modal = new ModalBuilder()
                .setCustomId('modal_criar_gift')
                .setTitle('🎁 Criar Gift de Membros');

            const inputQuantidade = new TextInputBuilder()
                .setCustomId('quantidade_gift')
                .setLabel('QUANTIDADE DE MEMBROS POR GIFT')
                .setPlaceholder('Ex: 50')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const inputQuantosGifts = new TextInputBuilder()
                .setCustomId('quantos_gifts')
                .setLabel('QUANTOS GIFTS CRIAR')
                .setPlaceholder('Ex: 3 (criará 3 gifts com a quantidade especificada)')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(inputQuantidade),
                new ActionRowBuilder().addComponents(inputQuantosGifts)
            );

            return interaction.showModal(modal);
        }

        // --- 4. MODAL SUBMIT: CRIAR GIFT ---
        if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'modal_criar_gift') {
            await interaction.deferReply({ ephemeral: true });

            const quantidade = parseInt(interaction.fields.getTextInputValue('quantidade_gift').trim());
            const quantosGifts = parseInt(interaction.fields.getTextInputValue('quantos_gifts').trim());
            const criadoPor = interaction.user.tag;

            // Validação
            if (isNaN(quantidade) || quantidade <= 0) {
                return interaction.editReply(`${Emojis.get('negative')} Informe uma quantidade válida de membros!`);
            }

            if (isNaN(quantosGifts) || quantosGifts <= 0) {
                return interaction.editReply(`${Emojis.get('negative')} Informe uma quantidade válida de gifts!`);
            }

            if (quantosGifts > 10) {
                return interaction.editReply(`${Emojis.get('negative')} Você pode criar no máximo 10 gifts por vez!`);
            }

            try {
                // Carregar configuração do bot
                const authData = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
                const botIds = Object.keys(authData);
                
                // Pega o primeiro bot configurado ou usa a estrutura direta
                let configAuth;
                if (authData.bot_id) {
                    // Estrutura direta (um único bot)
                    configAuth = authData;
                } else if (botIds.length > 0) {
                    // Estrutura com múltiplos bots (pega o primeiro)
                    configAuth = authData[botIds[0]];
                } else {
                    return interaction.editReply(`${Emojis.get('negative')} Nenhum bot configurado!`);
                }

                if (!configAuth || !configAuth.bot_id) {
                    return interaction.editReply(`${Emojis.get('negative')} Configuração do Bot Auth02 inválida!`);
                }

                // Verificar saldo disponível
                const infoRes = await axios.get(`${API_URL}/api/auth02/info/${configAuth.bot_id}`);

                const membrosDisponiveis = infoRes.data.membros || 0;
                const totalMembrosNecessarios = quantidade * quantosGifts;

                if (totalMembrosNecessarios > membrosDisponiveis) {
                    return interaction.editReply(
                        `${Emojis.get('negative')} Você tentou criar ${quantosGifts} gifts de \`${quantidade}\` membros cada (total: \`${totalMembrosNecessarios}\` membros), ` +
                        `mas seu bot possui apenas \`${membrosDisponiveis}\` verificados na database.`
                    );
                }

                // Criar múltiplos gifts
                const giftsCriados = [];
                
                for (let i = 0; i < quantosGifts; i++) {
                    try {
                        const giftRes = await axios.post(`${API_URL}/api/gifts/criar`, {
                            bot_id: configAuth.bot_id,
                            quantidade: quantidade,
                            criado_por: criadoPor
                        }, {
                            headers: { 
                                'Authorization': AUTH_TOKEN,
                                'Content-Type': 'application/json'
                            }
                        });

                        if (giftRes.data.sucesso) {
                            giftsCriados.push(giftRes.data.gift);
                        }
                    } catch (err) {
                        console.error(`Erro ao criar gift ${i + 1}:`, err.response?.data || err.message);
                    }
                }

                if (giftsCriados.length === 0) {
                    return interaction.editReply(`${Emojis.get('negative')} Erro ao criar gifts. Tente novamente.`);
                }

                // Montar mensagem de resposta
                let mensagem = `# Seus Gifts Membros Foram Criados Com Sucesso\n\n`;
                
                giftsCriados.forEach((gift) => {
                    // Usa link_resgate se disponível, senão usa link
                    const linkResgate = gift.link_resgate || gift.link;
                    mensagem += `${linkResgate} - ${gift.quantidade} membros\n`;
                });

                if (giftsCriados.length < quantosGifts) {
                    mensagem += `\n-# ⚠️ Foram criados ${giftsCriados.length} de ${quantosGifts} gifts solicitados.`;
                }

                return interaction.editReply({ content: mensagem });

            } catch (err) {
                console.error("Erro ao criar gifts:", err.response?.data || err.message);
                
                // Mensagem de erro mais detalhada
                let errorMsg = `${Emojis.get('negative')} Erro ao criar gifts:\n`;
                
                if (err.response?.data) {
                    errorMsg += `\`\`\`json\n${JSON.stringify(err.response.data, null, 2)}\n\`\`\``;
                } else {
                    errorMsg += `\`${err.message}\``;
                }
                
                return interaction.editReply(errorMsg);
            }
        }

        // --- 5. BOTÃO: CONSULTAR GIFTS CRIADOS ---
        if (interaction.isButton() && interaction.customId === 'consultar_gifts_criados') {
            await interaction.deferReply({ ephemeral: true });

            try {
                // Consultar gifts via API
                const giftsRes = await axios.get(`${API_URL}/api/gifts/listar`, {
                    headers: { 'Authorization': AUTH_TOKEN }
                });

                if (!giftsRes.data.sucesso) {
                    return interaction.editReply(`${Emojis.get('negative')} Erro ao consultar gifts.`);
                }

                const { estatisticas, gifts } = giftsRes.data;

                // Se não houver gifts
                if (!gifts || gifts.length === 0) {
                    const containerContent = res.main(
                        { type: 10, content: `-# Painel > Ilusion Cloud > Sistema OAuth02 > Consultar Gifts` },
                        { type: 14 },
                        { type: 10, content: `## 📋 Gifts Criados` },
                        { type: 14 },
                        { type: 10, content: `${Emojis.get('negative')} Nenhum gift foi criado ainda.` },
                        { type: 14 }
                    ).with({});

                    return interaction.editReply(containerContent);
                }

                // Pegar os últimos 10 gifts
                const giftsRecentes = gifts.slice(0, 10);

                // Criar descrição com lista de gifts
                let descricao = '';
                giftsRecentes.forEach((gift) => {
                    const statusEmoji = {
                        'ativo': '🟢',
                        'resgatado': '🟡',
                        'processando': '🟡',
                        'concluido': '✅'
                    }[gift.status] || '⚪';

                    descricao += `\n**${giftsRecentes.indexOf(gift) + 1}.** ${statusEmoji} \`${gift.codigo}\`\n`;
                    descricao += `> Bot: ${gift.bot_name} | Membros: ${gift.quantidade}\n`;
                    descricao += `> Status: \`${gift.status}\` | Criado: <t:${Math.floor(new Date(gift.criado_em).getTime() / 1000)}:R>\n`;
                    if (gift.link) {
                        descricao += `> [Link de Resgate](${gift.link})\n`;
                    }
                });

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Ilusion Cloud > Sistema OAuth02 > Consultar Gifts` },
                    { type: 14 },
                    { type: 10, content: `## 📊 Estatísticas de Gifts\n\n**Total de Gifts:** \`${estatisticas.total}\`\n**Ativos:** \`${estatisticas.ativos}\` | **Resgatados:** \`${estatisticas.resgatados}\`\n**Processando:** \`${estatisticas.processando}\` | **Concluídos:** \`${estatisticas.concluidos}\`` },
                    { type: 14 },
                    { type: 10, content: `## 📋 Últimos Gifts Criados\n${descricao}\n\n-# Mostrando ${giftsRecentes.length} de ${gifts.length} gifts` },
                    { type: 14 }
                ).with({});

                return interaction.editReply(containerContent);

            } catch (err) {
                console.error("Erro ao consultar gifts:", err.response?.data || err.message);
                
                // Mensagem de erro mais detalhada
                let errorMsg = `${Emojis.get('negative')} Erro ao consultar gifts:\n`;
                
                if (err.response?.data) {
                    errorMsg += `\`\`\`json\n${JSON.stringify(err.response.data, null, 2)}\n\`\`\``;
                } else {
                    errorMsg += `\`${err.message}\``;
                }
                
                return interaction.editReply(errorMsg);
            }
        }
    }
};
